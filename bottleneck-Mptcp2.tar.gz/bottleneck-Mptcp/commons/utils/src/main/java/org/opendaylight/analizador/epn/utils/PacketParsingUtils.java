/**
 * Copyright (c) 2014 Cisco Systems, Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */

package org.opendaylight.analizador.epn.utils;

import java.math.BigInteger;
import java.util.Arrays;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.yang.types.rev100924.MacAddress;


public abstract class PacketParsingUtils {

	//TAMAÑO DE LA DIRECCIÓN MAC:6 bytes
	private static final int MAC_ADDRESS_SIZE = 6;
	//POSICIÓN INICIAL DE LA DIRECCIÓN MAC DESTINO:0
	private static final int DST_MAC_START_POSITION = 0;
	//POSICIÓN FINAL DE LA DIRECCIÓN MAC DESTINO:6
	private static final int DST_MAC_END_POSITION = 6;
	//POSICIÓN INICIAL DE LA DIRECCIÓN MAC FUENTE:6	
	private static final int SRC_MAC_START_POSITION = 6;
	//POSICIÓN INICIAL DE LA DIRECCIÓN MAC FUENTE:12
	private static final int SRC_MAC_END_POSITION = 12;

	//POSICIÓN INICIAL DEL TIPO DE MENSAJE EN CAPA 3:12	
	private static final int ETHER_TYPE_START_POSITION = 12;
	//POSICIÓN INICIAL DEL TIPO DE MENSAJE EN CAPA 3:14	
	private static final int ETHER_TYPE_END_POSITION = 14;

	//POSICIÓN INICIAL DE VERSIÓN Y LONGITUD DE LA CABECERA IP:14	
	private static final int 	VERSION_Y_LONG_HEADER_IP__START_POSITION = 14;
	//POSICIÓN FINAL DE VERSIÓN Y LONGITUD DE LA CABECERA IP:15
	private static final int 	VERSION_Y_LONG_HEADER_IP_END_POSITION = 15;

	//POSICIÓN INICIAL DE CAMPO PROTOCOLO:23	
	private static final int CAMPO_PROTOCOL_START_POSITION =23;
	//POSICIÓN FINAL DE CAMPO PROTOCOLO:24	
	private static final int CAMPO_PROTOCOL_END_POSITION =24;

	//POSICIÓN INICIAL DE LA DIRECCIÓN IP FUENTE:26	
	private static final int IP_SRC_START_POSITION =26;
	//POSICIÓN FINAL DE LA DIRECCIÓN IP FUENTE:30
	private static final int IP_SRC_END_POSITION =30;

	//POSICIÓN INICIAL DE LA DIRECCIÓN IP DESTINO:30	    
	private static final int IP_DEST_START_POSITION =30;
	//POSICIÓN FINAL DE LA DIRECCIÓN IP DESTINO:34	    
	private static final int IP_DEST_END_POSITION =34;

	//POSICIÓN INICIAL DE LA LONGITUD DE LA CABECERA TCP::46	
	private static final int 	LONG_CABECERA_TCP_START_POSITION = 46;
	//POSICIÓN FINAL DE LA LONGITUD DE LA CABECERA TCP:47
	private static final int LONG_CABECERA_TCP_END_POSITION = 47;

	//POSICIÓN INICIAL DEL PUERTO FUENTE:34	    
	private static final int PUERTO_SRC_START_POSITION =34;
	//POSICIÓN FINAL DEL PUERTO FUENTE:34	    
	private static final int PUERTO_SRC_END_POSITION =36;

	//POSICIÓN INICIAL DEL PUERTO DESTINO:36	    
	private static final int PUERTO_DEST_START_POSITION =36;
	//POSICIÓN FINAL DEL PUERTO DESTINO:38    
	private static final int PUERTO_DEST_END_POSITION =38;

	//POSICIÓN INCIAL DEL CAMPO OPCIONES DE TCP:54	
	private static final int OPTIONS_TCP_START_POSITION = 54;
	//POSICIÓN FINAL DEL CAMPO OPCIONES DE TCP:54
	private static final int OPTIONS_TCP_END_POSITION = 54;



	private PacketParsingUtils() {

	}
	//EXTRAER DIRECCIÓN MAC DESTINO
	public static byte[] extraerDstMac(final byte[] MensajeRecibido) {
		return Arrays.copyOfRange(MensajeRecibido, DST_MAC_START_POSITION, DST_MAC_END_POSITION);
	}
	//EXTRAER DIRECCIÓN MAC FUENTE
	public static byte[] extraerSrcMac(final byte[] MensajeRecibido) {
		return Arrays.copyOfRange(MensajeRecibido, SRC_MAC_START_POSITION, SRC_MAC_END_POSITION);
	}
	//EXTRAER DEL CAMPO VERSION Y LONGITUD IP   
	public static byte[] extraerVersionAndLongCabeceraIP(final byte[] MensajeRecibido) {
		return Arrays.copyOfRange(MensajeRecibido, VERSION_Y_LONG_HEADER_IP__START_POSITION, VERSION_Y_LONG_HEADER_IP_END_POSITION);
	}
	//EXTRAER LONGITUD CABECERA TCP
	public static byte[] extraerLongCabeceraTCP(final byte[] MensajeRecibido , int DezplamientoCabeceraIP) {
		return Arrays.copyOfRange(MensajeRecibido, LONG_CABECERA_TCP_START_POSITION+DezplamientoCabeceraIP, LONG_CABECERA_TCP_END_POSITION
				+DezplamientoCabeceraIP);
	}
	//EXTRAER CAMPO OPCIONES TCP
	public static byte[] extraerCampoOpcionesTCP(final byte[] MensajeRecibido,int DezplamientoCabeceraIP,int LongitudCampoOpcionesTCP) {
		return Arrays.copyOfRange(MensajeRecibido, OPTIONS_TCP_START_POSITION+DezplamientoCabeceraIP, OPTIONS_TCP_END_POSITION
				+DezplamientoCabeceraIP+LongitudCampoOpcionesTCP);
	} 
	//EXTRAER EL TIPO ETHERNET
	public static byte[] extraerTipoEthernet(final byte[] MensajeRecibido) {
		return Arrays.copyOfRange(MensajeRecibido, ETHER_TYPE_START_POSITION, ETHER_TYPE_END_POSITION);
	}
	//EXTRAER EL TIPO DE PROTOCOLO
	public static byte[] extraerProtoType(final byte[] MensajeRecibido) {
		return Arrays.copyOfRange(MensajeRecibido, CAMPO_PROTOCOL_START_POSITION, CAMPO_PROTOCOL_END_POSITION);
	}
	//EXTRAER DIRECCIÓN IP FUENTE
	public static byte[] extraerIpSrc(final byte[] MensajeRecibido) {
		return Arrays.copyOfRange(MensajeRecibido, IP_SRC_START_POSITION, IP_SRC_END_POSITION);
	}
	//EXTRAER DIRECCIÓN IP DESTINO
	public static byte[] extraerIpDest(final byte[] MensajeRecibido) {
		return Arrays.copyOfRange(MensajeRecibido, IP_DEST_START_POSITION, IP_DEST_END_POSITION);
	}
	//EXTRAER PUERTO FUENTE
	public static byte[] extraerPuertoSrc(final byte[] MensajeRecibido, int DezplamientoCabeceraIP) {
		return Arrays.copyOfRange(MensajeRecibido, PUERTO_SRC_START_POSITION+DezplamientoCabeceraIP, PUERTO_SRC_END_POSITION
				+DezplamientoCabeceraIP);
	}
	//EXTRAER PUERTO DESTINO
	public static byte[] extraerPuertoDest(final byte[] MensajeRecibido,int DezplamientoCabeceraIP) {
		return Arrays.copyOfRange(MensajeRecibido, PUERTO_DEST_START_POSITION+DezplamientoCabeceraIP, PUERTO_DEST_END_POSITION
				+DezplamientoCabeceraIP);
	}

	
	//TRANSFORMAR EL ARREGLO DE BYTES A FORMATO DE DIRECCIÓN MAC DE TIPO STRING   
	public static String rawMacToString(byte[] rawMac) {
		if (rawMac != null && rawMac.length == 6) {
			StringBuffer sb = new StringBuffer();
			for (byte octet : rawMac) {
				sb.append(String.format(":%02X", octet));
			}
			return sb.substring(1);
		}
		return null;
	}
	//TRANSFORMAR DE ARREGLO DE BYTES A FORMATO DE DIRECCIÓN IP DE TIPO STRING
	public static String rawIpToString(byte[] rawIP) {
		if (rawIP != null && rawIP.length == 4) {
			StringBuffer sb = new StringBuffer();
			for (int octet : rawIP) {
				if(octet<0){
					int octet2 =(int) (256+octet);
					sb.append(String.format(".%01d", octet2));
				}
				else{
					sb.append(String.format(".%01d", octet));
				}
			}
			return sb.substring(1);
		}
		return null;
	}

	
	//TRANSFORMAR DE ARREGLO DE BYTES A STRING TIPO DE PROTOCOLO
	public static String rawTypeProtoToString(byte[] rawprotocolo) {
		if (rawprotocolo != null && rawprotocolo.length == 1) {
			StringBuffer sb = new StringBuffer();
			for (byte octet : rawprotocolo) {
				sb.append(String.format("%02X", octet));
			}
			return sb.substring(1);
		}
		return null;
	}



	//TRANSFORMAR DE ARREGLO DE BYTES EL CAMPO PROTOCOLO DE CAPA4 A STRING 
	public static String rawProtocolToString(byte[] rawPROTOCOLOCAPA4) {
		if (rawPROTOCOLOCAPA4 != null && rawPROTOCOLOCAPA4.length == 1) {
			StringBuffer sb = new StringBuffer();
			for (byte octet : rawPROTOCOLOCAPA4) {
				sb.append(String.format(".%02X", octet));
			}
			return sb.substring(1);
		}
		return null;
	}


	//EXTRAER OCHO BYTES
	public static byte[] extraer8B(final byte[] MensajeRecibido , int LONGITUDVARIABLE1, int LONGITUDVARIABLE2) {
		return Arrays.copyOfRange(MensajeRecibido, OPTIONS_TCP_START_POSITION+LONGITUDVARIABLE1+LONGITUDVARIABLE2, OPTIONS_TCP_END_POSITION
				+LONGITUDVARIABLE1+LONGITUDVARIABLE2+8);
	}
	public static String extraer8B_reduccion(final byte[] Byte8 ) {
		int long0 = Byte8.length;
		String Byte8_String = Raw_A_String(Byte8, long0);
		int long1=(Byte8_String.length()+1)/3;
		short[] Byte8_Short= String_A_ShortArray(Byte8_String, long1);
		int long2=Byte8_Short.length;
		BigInteger Byte8_BI =Hexadecimal_A_Decimal(Byte8_Short, long2);
		BigInteger uno = new BigInteger("0");
		if(Byte8_BI==null){Byte8_BI=uno;
		String VALOR="0";
		return VALOR;}else{		if(Byte8_BI.equals(uno)==true){String VALOR="0";
		return VALOR;
		}else{String VALOR =Byte8_BI.toString();
		return VALOR;}
		}
	}

	//EXTRAER CUATRO BYTES
	public static byte[] extraer4B(final byte[] MensajeRecibido , int LONGITUDVARIABLE1, int LONGITUDVARIABLE2) {
		return Arrays.copyOfRange(MensajeRecibido, OPTIONS_TCP_START_POSITION+LONGITUDVARIABLE1+LONGITUDVARIABLE2, OPTIONS_TCP_END_POSITION
				+LONGITUDVARIABLE1+LONGITUDVARIABLE2+4);
	}
	public static String extraer4B_reduccion(final byte[] Byte4 ) {
		int long0 = Byte4.length;
		String Byte4_String = Raw_A_String(Byte4, long0);
		int long1=(Byte4_String.length()+1)/3;
		short[] Byte4_Short= String_A_ShortArray(Byte4_String, long1);
		int long2=Byte4_Short.length;
		BigInteger Byte4_BI =Hexadecimal_A_Decimal(Byte4_Short, long2);
		BigInteger uno = new BigInteger("0");
		if(Byte4_BI==null)
		{Byte4_BI=uno;
		String VALOR="0";
		return VALOR;}
		else{		if(Byte4_BI.equals(uno)==true){String VALOR="0";
		return VALOR;
		}else{String VALOR =Byte4_BI.toString();
		return VALOR;}
		}
	}


	//EXTRAER DOS BYTES
	public static byte[] extraer2B(final byte[] MensajeRecibido , int LONGITUDVARIABLE1, int LONGITUDVARIABLE2) {
		return Arrays.copyOfRange(MensajeRecibido, OPTIONS_TCP_START_POSITION+LONGITUDVARIABLE1+LONGITUDVARIABLE2, OPTIONS_TCP_END_POSITION
				+LONGITUDVARIABLE1+LONGITUDVARIABLE2+2);
	}
	public static String extraer2B_reduccion(final byte[] Byte2 ) {
		int long0 = Byte2.length;
		String Byte2_String = Raw_A_String(Byte2, long0);
		int long1=(Byte2_String.length()+1)/3;
		short[] Byte2_Short= String_A_ShortArray(Byte2_String, long1);
		int long2=Byte2_Short.length;
		BigInteger uno = new BigInteger("0");
		BigInteger Byte2_BI =Hexadecimal_A_Decimal(Byte2_Short, long2);
		if(Byte2_BI==null){Byte2_BI=uno;
		String VALOR="0";
		return VALOR;}else{		if(Byte2_BI.equals(uno)==true){String VALOR="0";
		return VALOR;
		}else{String VALOR =Byte2_BI.toString();
		return VALOR;}
		}

	}


	//CONVERTIR DE ARREGLO DE BYTES A HEXADECIMAL
	public static String Raw_A_String(byte[] rawMac,int longitud) {
		if (rawMac != null && rawMac.length == longitud) {
			StringBuffer sb = new StringBuffer();
			for (byte octet : rawMac) {
				sb.append(String.format(":%02X", octet));
			}
			return sb.substring(1);
		}
		return null;
	}

	//POTENCIAS DE 2
	public static long potenciar(double numero) 
	{ 
		return (long)Math.pow(2, numero); 
	} 

	//OBTENER UN ARREGLO DE TIPO SHORT DE UNA VARIABLE TIPO STRING
	public static short[] String_A_ShortArray(String address, int longitud) {
		String[] elements = address.split(":");
		short[] addressInBytes = new short[longitud];
		for (int i = 0; i < longitud; i++) {
			String element = elements[i];
			addressInBytes[i] = (short)Integer.parseInt(element, 16);
		}
		return addressInBytes;

	}


	//OBTENER EL NÚMERO DECIMAL DE UN HEXADECIMAL
	public static BigInteger Hexadecimal_A_Decimal(short[] Dato, int Longitud) {

		long SumaT=0;
		//Inicio variable para el resultado final
		BigInteger ResultadoDato = null;
		//Realizo un barrido en función de la longitud del arreglo short de Dato
		for (int x=Longitud-1 ; x >= 0  ;x--)
		{
			//Contador incremental para las potencias
			long ContIncremento=(Longitud-1)-x;				
			//Arreglo de UNOs para realizar comparaciones
			int UNOEntero=1;
			String UNOString = Integer.toBinaryString(UNOEntero);
			char UNOChar[] = UNOString.toCharArray();

			String DatoString = Integer.toBinaryString(Dato[x]);
			char DatoChar[] = DatoString.toCharArray();
			int LongitudDato = DatoChar.length;

			// Segun la longitud del arreglo de dato se realizará el calculo para obtener la
			// variable ResultadoDato
			switch(LongitudDato){
			case 1:
				//Inicializamos la variable local para realizar el calculo
				long Suma1 = 0;  
				for (int d=0 ; d < LongitudDato ;d++){	
					int q=0;
					long DatoLong = DatoChar[q];
					if(DatoLong==UNOChar[0]){	
						double ContIncrementoDouble=ContIncremento;
						double z=d;
						double exponente= ((ContIncrementoDouble*8)+z);

						long Potencia = PacketParsingUtils.potenciar(exponente);
						long Suma = 1*Potencia;
						Suma1=Suma;
						SumaT=SumaT+Suma;
						BigInteger Valor1 = new BigInteger("0");
						String SumaTString = Long.toString(SumaT); 
						BigInteger Valor2 = new BigInteger(SumaTString);
						//Suma de dos valores de tipo BigInteger
						BigInteger resultado1 = Valor1.add(Valor2);
						ResultadoDato = resultado1;
					}

					else{}


				}
				break;
			case 2:


				long suma2 = 0;  
				for (int d=0 ; d < LongitudDato ;d++)
				{	int q=d+(1-2*d);
				long DatoLong = DatoChar[q];
				if(DatoLong==UNOChar[0]){	
					double ContIncrementoDouble=ContIncremento;
					double z=d;
					double exponente= ((ContIncrementoDouble*8)+z);
					long Potencia = PacketParsingUtils.potenciar(exponente);
					long Suma = 1*Potencia;
					suma2=Suma;
					SumaT=SumaT+Suma;
					BigInteger Valor1 = new BigInteger("0");
					String SumaTString = Long.toString(SumaT); 
					BigInteger Valor2 = new BigInteger(SumaTString);

					BigInteger Resultado = Valor1.add(Valor2);
					ResultadoDato = Resultado;

				}

				else{}
				}
				break;

			case 3:
				long suma3 = 0;  
				for (int d=0 ; d < LongitudDato ;d++)
				{	int q=d+(2-2*d);
				long DatoLong = DatoChar[q];
				if(DatoLong==UNOChar[0]){	
					double ContIncrementoDouble=ContIncremento;
					double z=d;
					double exponente= ((ContIncrementoDouble*8)+z);
					long Potencia = PacketParsingUtils.potenciar(exponente);
					long Suma = 1*Potencia;
					suma3=Suma;
					SumaT=SumaT+Suma;
					BigInteger Valor1 = new BigInteger("0");
					String SumaTString = Long.toString(SumaT); 
					BigInteger Valor2 = new BigInteger(SumaTString);

					BigInteger Resultado = Valor1.add(Valor2);
					ResultadoDato = Resultado;

				}
				else{}
				}
				break;
			case 4:
				long suma4 = 0;  
				for (int d=0 ; d < LongitudDato ;d++)
				{	int q=d+(3-2*d);
				long DatoLong = DatoChar[q];
				if(DatoLong==UNOChar[0]){	
					double ContIncrementoDouble=ContIncremento;
					double z=d;
					double exponente= ((ContIncrementoDouble*8)+z);
					long Potencia = PacketParsingUtils.potenciar(exponente);
					long Suma = 1*Potencia;
					suma4=Suma;
					SumaT=SumaT+Suma;
					BigInteger Valor1 = new BigInteger("0");
					String SumaTString = Long.toString(SumaT); 
					BigInteger Valor2 = new BigInteger(SumaTString);

					BigInteger Resultado = Valor1.add(Valor2);
					ResultadoDato = Resultado;

				}
				else{}
				}
				break;
			case 5:
				long suma5 = 0;  
				for (int d=0 ; d < LongitudDato ;d++)
				{	int q=d+(4-2*d);
				long DatoLong = DatoChar[q];
				if(DatoLong==UNOChar[0]){	
					double ContIncrementoDouble=ContIncremento;
					double z=d;
					double exponente= ((ContIncrementoDouble*8)+z);
					long Potencia = PacketParsingUtils.potenciar(exponente);
					long Suma = 1*Potencia;
					suma5=Suma;
					SumaT=SumaT+Suma;
					BigInteger Valor1 = new BigInteger("0");
					String SumaTString = Long.toString(SumaT); 
					BigInteger Valor2 = new BigInteger(SumaTString);

					BigInteger Resultado = Valor1.add(Valor2);
					ResultadoDato = Resultado;

				}
				else{}
				}
				break;
			case 6:
				long suma6 = 0;  
				for (int d=0 ; d < LongitudDato ;d++)
				{	int q=d+(5-2*d);
				long DatoLong = DatoChar[q];
				if(DatoLong==UNOChar[0]){	
					double ContIncrementoDouble=ContIncremento;
					double z=d;
					double exponente= ((ContIncrementoDouble*8)+z);
					long Potencia = PacketParsingUtils.potenciar(exponente);
					long Suma = 1*Potencia;
					suma6=Suma;
					SumaT=SumaT+Suma;
					BigInteger Valor1 = new BigInteger("0");
					String SumaTString = Long.toString(SumaT); 
					BigInteger Valor2 = new BigInteger(SumaTString);

					BigInteger Resultado = Valor1.add(Valor2);
					ResultadoDato = Resultado;

				}
				else{}
				}
				break;
			case 7:
				long suma7 = 0;  
				for (int d=0 ; d < LongitudDato ;d++)
				{	int q=d+(6-2*d);
				long DatoLong = DatoChar[q];
				if(DatoLong==UNOChar[0]){	
					double ContIncrementoDouble=ContIncremento;
					double z=d;
					double exponente= ((ContIncrementoDouble*8)+z);
					long Potencia = PacketParsingUtils.potenciar(exponente);
					long Suma = 1*Potencia;
					Suma1=Suma;
					SumaT=SumaT+Suma;
					BigInteger Valor1 = new BigInteger("0");
					String SumaTString = Long.toString(SumaT); 
					BigInteger Valor2 = new BigInteger(SumaTString);

					BigInteger Resultado = Valor1.add(Valor2);
					ResultadoDato = Resultado;

				}
				else{}
				}
				break;
			case 8:

				for (int d=0 ; d < LongitudDato ;d++)
				{	int q=d+(7-2*d);
				long DatoLong = DatoChar[q];
				if (DatoLong==UNOChar[0]){
					double ContIncrementoDouble=ContIncremento;
					double z=d;
					double exponente= ((ContIncrementoDouble*8)+z);

					if (exponente==63){
						BigInteger Valor1 = new BigInteger("9223372036854775808");
						String SumaTString = Long.toString(SumaT); 
						BigInteger Valor2 = new BigInteger(SumaTString);

						BigInteger Resultado = Valor1.add(Valor2);
						ResultadoDato = Resultado;

					}
					else{
						long Potencia = PacketParsingUtils.potenciar(exponente);
						long Suma = 1*Potencia;
						SumaT=SumaT+Suma;
						BigInteger Valor1= new BigInteger("0");
						String SumaTString = Long.toString(SumaT); 
						BigInteger Valor2 = new BigInteger(SumaTString);

						BigInteger Resultado = Valor1.add(Valor2);
						ResultadoDato = Resultado;
					}
				}
				}
				break;	
			}
		}

		return ResultadoDato;
	}    
}