package org.opendaylight.analizador.epn.analizadormptcp.impl;

import java.util.HashSet;
import java.util.Set;

public class Graph {
	private Set<Nodo> nodes = new HashSet<>();

	public void addNode(Nodo nodeA) {
		nodes.add(nodeA);
	}

	public Set<Nodo> getNodes() {
		return nodes;
	}

	public void setNodes(Set<Nodo> nodes) {
		this.nodes = nodes;
	}
}
