package org.opendaylight.analizador.epn.analizadormptcp.impl;

import java.util.ArrayList;

public class Rutas {

	public ArrayList<String> rutascortas=new ArrayList<>();
	public String hash;
	public int contador;
	public int contadorJOIN;
	public Rutas() {

	}

	public Rutas(ArrayList<String> rutascortas,String hash,int contador, int contadorJOIN) {

		this.rutascortas= rutascortas;
		this.hash=hash;
		this.contador = contador;
		this.contadorJOIN= contadorJOIN;
	}
	public ArrayList<String> getrutascortas(){
		return this.rutascortas;
	}
	public String gethash() {
		return this.hash;
	}
	public int getconador() {
		return this.contador;
	}
	public void sethash(String j) {
		this.hash=j;
	}
	public void setcontador(int i) {
		this.contador=i;
	}
	public int getcontadorJOIN() {
		return this.contadorJOIN;
	}
	public void setcontadorJOIN(int j) {
		this.contadorJOIN=j;
	}
}
