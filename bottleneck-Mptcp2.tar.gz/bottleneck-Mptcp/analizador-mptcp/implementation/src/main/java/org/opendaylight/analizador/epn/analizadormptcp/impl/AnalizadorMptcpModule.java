package org.opendaylight.analizador.epn.analizadormptcp.impl;

/*
 * DECLARACIÓN DE BIBLIOTECAS A UTILIZAR
 */

//import org.opendaylight.analizador.epn.utils.GenericTransactionUtils;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
//import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.controller.sal.binding.api.NotificationProviderService;
import org.opendaylight.controller.sal.binding.api.RpcProviderRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.table.Flow;
//import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeId;
//import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;

public class AnalizadorMptcpModule
		extends org.opendaylight.analizador.epn.analizadormptcp.impl.AbstractAnalizadorMptcpModule {

	private final Logger LOG = LoggerFactory.getLogger(this.getClass());

	public AnalizadorMptcpModule(org.opendaylight.controller.config.api.ModuleIdentifier identifier,
			org.opendaylight.controller.config.api.DependencyResolver dependencyResolver) {
		super(identifier, dependencyResolver);
	}

	public AnalizadorMptcpModule(org.opendaylight.controller.config.api.ModuleIdentifier identifier,
			org.opendaylight.controller.config.api.DependencyResolver dependencyResolver,
			org.opendaylight.analizador.epn.analizadormptcp.impl.AnalizadorMptcpModule oldModule,
			java.lang.AutoCloseable oldInstance) {
		super(identifier, dependencyResolver, oldModule, oldInstance);
	}

	@Override
	public void customValidation() {

	}



	@Override
	public java.lang.AutoCloseable createInstance() {

		final DataBroker dataBroker = getDataBrokerDependency();
		RpcProviderRegistry rpcRegistry = getRpcRegistryDependency();
		NotificationProviderService notificationService = getNotificationServiceDependency();


		final AnalizadorMP_TCP analizadormptcp = new AnalizadorMP_TCP(dataBroker, notificationService, rpcRegistry);

		LOG.info("Analizador Mptcp (instance {}) initialized.", analizadormptcp);
		System.out.println("Finalizo");
		return analizadormptcp;

	}

}