/*
 * Copyright (C) 2016 EPN

 *
 */

/* IMPORTACIÓN DE BIBLIOTECAS A UTILIZAR EN EL CONSTRUCTOR ANALIZADOR MP-TCP COMO: BIBLIOTECAS DE ESCRITURA DE DATOS, ACCESO
 * AL DATA STORE, ESCUCHA DE NOTIFICACIONES COMO LEVANTAMIENTO DE SWITCHES Y SUS PUERTOS, NOTIFICACIONES DE ESCUCHA DE PAQUETES QUE ENVIEN
 * LOS SWITCHES OPENFLOW AL CONTROLADOR, BIBLIOTECAS NECESARIAS PARA LA CREACIÓN DE FLUJOS, ESCUCHA DE PAQUETES IPV4, ENTRE OTRAS.
 *
 */

package org.opendaylight.analizador.epn.analizadormptcp.impl;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import org.opendaylight.controller.md.sal.binding.api.DataBroker;
import org.opendaylight.controller.md.sal.binding.api.ReadOnlyTransaction;
import org.opendaylight.controller.md.sal.common.api.data.LogicalDatastoreType;
import org.opendaylight.controller.sal.binding.api.NotificationProviderService;
import org.opendaylight.controller.sal.binding.api.RpcProviderRegistry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.Uri;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.action.OutputActionCaseBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.action.output.action._case.OutputActionBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.list.Action;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.list.ActionBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.action.types.rev131112.action.list.ActionKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.FlowCapableNode;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.FlowId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.Table;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.TableKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.table.Flow;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.table.FlowBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.inventory.rev130819.tables.table.FlowKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.service.rev130819.SalFlowService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.FlowCookie;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.FlowModFlags;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.OutputPortValues;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.flow.InstructionsBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.flow.Match;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.flow.MatchBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.instruction.ApplyActionsCaseBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.instruction.apply.actions._case.ApplyActions;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.instruction.apply.actions._case.ApplyActionsBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.list.Instruction;
import org.opendaylight.yang.gen.v1.urn.opendaylight.flow.types.rev131026.instruction.list.InstructionBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRemoved;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorUpdated;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeRemoved;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeUpdated;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.Nodes;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.OpendaylightInventoryListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnector;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.NodeKey;
import org.opendaylight.yang.gen.v1.urn.opendaylight.l2.types.rev130827.EtherType;
import org.opendaylight.yang.gen.v1.urn.opendaylight.l2switch.loopremover.rev140714.StpStatus;
import org.opendaylight.yang.gen.v1.urn.opendaylight.l2switch.loopremover.rev140714.StpStatusAwareNodeConnector;
import org.opendaylight.yang.gen.v1.urn.opendaylight.model.match.types.rev131026.ethernet.match.fields.EthernetTypeBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.model.match.types.rev131026.match.EthernetMatchBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.model.match.types.rev131026.match.IpMatchBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.model.match.types.rev131026.match.layer._3.match.Ipv4MatchBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.model.match.types.rev131026.match.layer._4.match.TcpMatchBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketReceived;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.TransmitPacketInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.openflow.common.config.impl.rev140326.OpenflowProviderImplService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.port.statistics.rev131214.OpendaylightPortStatisticsService;
import org.opendaylight.yangtools.concepts.Registration;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.basepacket.rev140528.packet.chain.grp.PacketChain;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.basepacket.rev140528.packet.chain.grp.packet.chain.packet.RawPacket;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.ipv4.rev140528.Ipv4PacketListener;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.ipv4.rev140528.Ipv4PacketReceived;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.ipv4.rev140528.ipv4.packet.received.packet.chain.packet.Ipv4Packet;
//import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.opendaylight.analizador.epn.utils.GenericTransactionUtils;
import org.opendaylight.analizador.epn.utils.PacketParsingUtils;
import org.opendaylight.analizador.epn.utils.inventory.InventoryUtils;
import com.google.common.collect.Lists;

import aQute.lib.base64.Base64;

import java.io.BufferedReader;
import java.io.File;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.loop.remover.impl.rev140528.LoopRemoverModule;

/*
 * CREACIÓN CLASE ANALIZADOR MP-TCP Y LLAMADO A LAS INTERFACES AUTOLOCESABLE,
 *  PACKETPROCESSINGLISTENER, OPENDAYLIGHTINVENTORYLISTENER E IPV4PACKETLISTENER
 */
public class AnalizadorMP_TCP
		implements AutoCloseable, PacketProcessingListener,OpendaylightInventoryListener  {
	private final Logger LOG = LoggerFactory.getLogger(this.getClass());


	String ipinicio ;
	String ipfinal ;

	// Members related to MD-SAL operations
	private List<Registration> registrations;
	private DataBroker dataBroker;
	private PacketProcessingService packetProcessingService;
	private byte[] Campo_Opciones_TCP_Raw;
	private byte[] Paquete;
	private int Contador_mensajes_MPTCP_dentro_del_Paquete_Recibido;
	private int Puntero_Mensajes_Campo_Opciones_TCP;
	private short tabla_id;
	private int prioridad_flujo_proactivo = 200;
	private AtomicLong cookie_uno = new AtomicLong(0x2b00000000000000L);
	private int contadorJOIN = 0;
	private int Longitud_Cabecera_IP_variable;
	private int contadorreglas = 0;
	Map<String, String> hostpip = new HashMap<>();
	ArrayList<String> rutascortas = new ArrayList<String>();
	HashMap<String, Rutas> llaverutas = new HashMap<String, Rutas>();
	public AnalizadorMP_TCP(final DataBroker dataBroker, NotificationProviderService notificationService,
			RpcProviderRegistry rpcProviderRegistry) {
		// Store the data broker for reading/writing from inventory store
		this.dataBroker = dataBroker;

		// Get access to the packet processing service for making RPC calls
		// later
		this.packetProcessingService = rpcProviderRegistry.getRpcService(PacketProcessingService.class);

		// List used to track notification (both data change and YANG-defined)
		// listener registrations
		this.registrations = Lists.newArrayList();

		// Register this object for receiving notifications when there are
		// PACKET_INs
		registrations.add(notificationService.registerNotificationListener(this));

	}

	@Override
	public void close() throws Exception {
		for (Registration registration : registrations) {
			registration.close();
		}
		registrations.clear();
	}

	/*
	 *
	 * MÉTODO QUE ESCUCHA PAQUETES QUE ENVIAN LOS SWITCHES AL CONTROLADOR
	 *
	 */

	@Override
	public void onPacketReceived(PacketReceived notification) {


		//		System.out.println("Entro el paquete");

		Paquete = notification.getPayload();
		try {

			byte[] PROTOCOLCAPA4Raw = PacketParsingUtils.extraerProtoType(Paquete);
			final String ID_Protocolo_Capa_4 = PacketParsingUtils.rawProtocolToString(PROTOCOLCAPA4Raw);
			if(Integer.parseInt(ID_Protocolo_Capa_4)==6){
//				System.out.println("Entro el paquete TCP");
				NodeConnectorRef ingressNodeConnectorRef = notification.getIngress();
				final NodeId path_id_switch = InventoryUtils.getNodeId(ingressNodeConnectorRef);
				byte[] MacFuenteRawAnalizador = PacketParsingUtils.extraerSrcMac(Paquete);
				final String MacFuenteAnalizador = PacketParsingUtils.rawMacToString(MacFuenteRawAnalizador);
				byte[] MacDestinoRawAnalizador = PacketParsingUtils.extraerDstMac(Paquete);
				final String MacDestinoAnalizador = PacketParsingUtils.rawMacToString(MacDestinoRawAnalizador);
				byte[] VersionAndLongitudCabeceraIPRaw = PacketParsingUtils.extraerVersionAndLongCabeceraIP(Paquete);
				byte LongitudCabeceraIP = VersionAndLongitudCabeceraIPRaw[0];
				String LongitudCabeceraIPString = Integer.toHexString(LongitudCabeceraIP & 0xf);
				int Longitud_Cabecera_IP_Entero = 0;
				Longitud_Cabecera_IP_Entero = Integer.parseInt(LongitudCabeceraIPString);
				byte[] etherTypeRaw = PacketParsingUtils.extraerTipoEthernet(notification.getPayload());
				int etherType = (0x0000ffff & ByteBuffer.wrap(etherTypeRaw).getShort());

				if (etherType == 0x88cc) {
					return;
				}

				int Longitud_Cabecera_IP_variable = 0;

				if (Longitud_Cabecera_IP_Entero == 5) {
					Longitud_Cabecera_IP_variable = 0;
				} else {
					Longitud_Cabecera_IP_variable = (Longitud_Cabecera_IP_Entero - 5) * 4;
				}

				byte[] ID_Tipo_Ethernet_Raw = PacketParsingUtils.extraerTipoEthernet(Paquete);
				int ID_Tipo_Ethernet = (0x0000ffff & ByteBuffer.wrap(ID_Tipo_Ethernet_Raw).getShort());
				byte[] LongCabeceraTCPRaw = PacketParsingUtils.extraerLongCabeceraTCP(Paquete,
						Longitud_Cabecera_IP_variable);
				byte LCTCP = LongCabeceraTCPRaw[0];

				int LONGITUD_CABECERA_TCP = LCTCP >> 2;
				int LONG_CABECERA_TCP = (LONGITUD_CABECERA_TCP & 0x3F);
				int LONG_CAMPO_OPCIONES_TCP = LONG_CABECERA_TCP - 20;
				Campo_Opciones_TCP_Raw = PacketParsingUtils.extraerCampoOpcionesTCP(Paquete,
						Longitud_Cabecera_IP_variable, LONG_CAMPO_OPCIONES_TCP);


				byte[] ipFuenteRaw = PacketParsingUtils.extraerIpSrc(Paquete);
				String ipFuenteAnalizador = PacketParsingUtils.rawIpToString(ipFuenteRaw);
				final MensajesMP_TCP mensajes = new MensajesMP_TCP();
				byte[] ipDestinoRaw = PacketParsingUtils.extraerIpDest(Paquete);
				String ipDestinoAnalizador = PacketParsingUtils.rawIpToString(ipDestinoRaw);



				for (Puntero_Mensajes_Campo_Opciones_TCP = 0; Puntero_Mensajes_Campo_Opciones_TCP < Campo_Opciones_TCP_Raw.length; Puntero_Mensajes_Campo_Opciones_TCP++) {
					if ((Campo_Opciones_TCP_Raw[Puntero_Mensajes_Campo_Opciones_TCP] != 1)
							&& (Campo_Opciones_TCP_Raw[Puntero_Mensajes_Campo_Opciones_TCP] != 30)) {

						Puntero_Mensajes_Campo_Opciones_TCP = Puntero_Mensajes_Campo_Opciones_TCP
								+ Campo_Opciones_TCP_Raw[Puntero_Mensajes_Campo_Opciones_TCP + 1] - 1;

					} else if (Campo_Opciones_TCP_Raw[Puntero_Mensajes_Campo_Opciones_TCP] == 30) {
						break;
					}
				}

				// SI EL IDENTIFICADOR DE TIPO DE MENSAJE DEL MENSAJE EVALUADO
				// ES DIFERENTE
				// A 1 Y A 30, SE INCREMENTA EL PUNTERO
				// Puntero_Mensajes_Campo_Opciones_TCP
				// PARA LEER EL SIGUIENTE MENSAJE
				// NOTA: SI EL INDENTIFICADOR DE TIPO DE MENSAJE ES 1, NO SE
				// REALIZA NIGUN
				// CAMBIO EN EL VALOR DEL PUNTERO, YA DICHO MENSAJE SOLO TIENE
				// LONGITUD 1 BYTE

				// SE VERIFICA SI EL CAMPO IDENTIFICADOR DE TIPO DE MENSAJE ES
				// 30.


				mensajes.iniciar(Campo_Opciones_TCP_Raw, Puntero_Mensajes_Campo_Opciones_TCP, Paquete,
						Longitud_Cabecera_IP_variable, MacFuenteAnalizador, MacDestinoAnalizador, ipFuenteAnalizador,
						ipDestinoAnalizador, path_id_switch);

				byte SubtipoMPTCPByte = Campo_Opciones_TCP_Raw[Puntero_Mensajes_Campo_Opciones_TCP + 2];
				String ejemplo = mensajes.getSubtipoMPTCPString();
				int ejemploint = Integer.parseInt(ejemplo);
				int SubtipoMPTCPEntero = (SubtipoMPTCPByte) >> 4;
				NodeConnectorId jk2 = InventoryUtils.getNodeConnectorId(ingressNodeConnectorRef);
				NodeId ejemplo3 = InventoryUtils.getNodeId(jk2);
				NodeConnectorId jk1 = InventoryUtils.getNodeConnectorId(ingressNodeConnectorRef);

				int n = 0;
				String[] k = jk1.getValue().toString().split(":");
				if (Integer.parseInt(k[1]) == 5) {
					n = 0;
				} else {
					n = 1;
				}
//				System.out.println(mensajes.getLongitudCampoMP_Capable());

				if (ejemploint == 0 && mensajes.getLongitudCampoMP_Capable()==12) {
					System.out.println("Entro al Capable 1");
//					Map<String, String> hostpip = new HashMap<>();
					String ip, linkhostswitch;
					String puertoswitch1, puertoswitch2;
					int numeronodos = 0, numeronodo1=0, numeronodo2=0;
					List<List<String>> switches = new ArrayList<List<String>>();
					switches.add(new ArrayList<String>());
					switches.add(new ArrayList<String>());
					switches.add(new ArrayList<String>());
					switches.add(new ArrayList<String>());
					List<List<String>> switches2 = new ArrayList<List<String>>();
					switches2.add(new ArrayList<String>());
					int nodoinicio = 0;
					int nodofinal = 0;

					try{
//
						String url = "http://127.0.0.1:8181/restconf/operational/network-topology:network-topology";
						URL obj = new URL(url);
						HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
						String userPassword = "admin:admin";
						conn.setRequestMethod("GET");
						String authEncBytes = org.apache.commons.codec.binary.Base64
								.encodeBase64String(userPassword.getBytes());
						conn.setRequestProperty("Authorization", "Basic " + authEncBytes);
						conn.setRequestProperty("Accept", "application/json");
						InputStream content = conn.getInputStream();
						BufferedReader in = new BufferedReader(new InputStreamReader(content));
						String line = "";
//
						StringBuffer result = new StringBuffer();
						while ((line = in.readLine()) != null) {
							result.append(line);
						}
						line = in.readLine();

						org.json.JSONObject jsonTopology = new org.json.JSONObject(result.toString());
						for (int i = 0; i < jsonTopology.getJSONObject("network-topology").getJSONArray("topology").getJSONObject(0)
								.getJSONArray("node").length(); i++) {
							if (jsonTopology.getJSONObject("network-topology").getJSONArray("topology").getJSONObject(0)
									.getJSONArray("node").getJSONObject(i).get("node-id").toString().indexOf("host") == 0) {
								for (int j = 0; j < jsonTopology.getJSONObject("network-topology").getJSONArray("topology")
										.getJSONObject(0).getJSONArray("node").getJSONObject(i)
										.getJSONArray("host-tracker-service:addresses").length(); j++) {
									ip = jsonTopology.getJSONObject("network-topology").getJSONArray("topology").getJSONObject(0)
											.getJSONArray("node").getJSONObject(i).getJSONArray("host-tracker-service:addresses")
											.getJSONObject(j).get("ip").toString();
									linkhostswitch = jsonTopology.getJSONObject("network-topology").getJSONArray("topology")
											.getJSONObject(0).getJSONArray("node").getJSONObject(i)
											.getJSONArray("host-tracker-service:attachment-points").getJSONObject(j).get("tp-id")
											.toString();
									hostpip.put(ip, linkhostswitch);
								}
							}
						}
						ipinicio= ipFuenteAnalizador;
//						System.out.println("Ip de Fuente");
//						System.out.println(ipinicio);
						ipfinal = ipDestinoAnalizador;
//						System.out.println("Ip de Destino");
//						System.out.println(ipfinal);

						nodoinicio = Integer.parseInt(hostpip.get(ipinicio).split(":")[1]);
//						System.out.println("Nodo de entrada");
//						System.out.println(nodoinicio);
						nodofinal = Integer.parseInt(hostpip.get(ipfinal).split(":")[1]);
//						System.out.println("Nodo de final");
//						System.out.println(nodofinal);
						for (int i = 0; i < jsonTopology.getJSONObject("network-topology").getJSONArray("topology").getJSONObject(0)
								.getJSONArray("link").length(); i++) {
							if (jsonTopology.getJSONObject("network-topology").getJSONArray("topology").getJSONObject(0)
									.getJSONArray("link").getJSONObject(i).get("link-id").toString().indexOf("host") == -1) {
								puertoswitch1 = jsonTopology.getJSONObject("network-topology").getJSONArray("topology").getJSONObject(0)
										.getJSONArray("link").getJSONObject(i).getJSONObject("source").get("source-tp").toString();
								puertoswitch2 = jsonTopology.getJSONObject("network-topology").getJSONArray("topology").getJSONObject(0)
										.getJSONArray("link").getJSONObject(i).getJSONObject("destination").get("dest-tp")
										.toString();
								switches.get(0).add(puertoswitch1);
								switches.get(1).add(puertoswitch2);
								switches.get(2).add(puertoswitch1.split(":")[1]);
								switches.get(3).add(puertoswitch2.split(":")[1]);
							}
						}
//						System.out.println("Nodos de entrada");
//						System.out.println(switches);
						for (int i = 0; i < switches.get(0).size(); i++) {
							numeronodo1 = Integer.parseInt(switches.get(2).get(i));
							numeronodo2 = Integer.parseInt(switches.get(3).get(i));
							if (numeronodo1 > numeronodo2) {
								if (numeronodo1 > numeronodos) {
									numeronodos = numeronodo1;
								}
							} else {
								if (numeronodo2 > numeronodos) {
									numeronodos = numeronodo2;
								}
							}
						}
//						System.out.println("Nodos de entrada 0");
//						System.out.println(numeronodos);
//						System.out.println("Nodos de entrada 1");
//						System.out.println(numeronodo1);
//						System.out.println("Nodos de entrada 2");
//						System.out.println(numeronodo2);

					}catch (Exception e) {
						// TODO: handle exception
						System.out.println(e);
					}
					int flag=0;
					int flagderutas;
					int nodoiniciointer=nodoinicio;
					int variableintermedia=0;
					int contadord=0;
					String nodosinter="";
					String nodosintercompletosinicio="";

					while (flag == 0) {
						flagderutas = 0;
						for (int i = 0; switches.get(0).size() > i; i++) {
							if (Integer.parseInt(switches.get(2).get(i)) == nodoiniciointer) {
								flagderutas++;
								if (flagderutas == 1) {
									variableintermedia = i;
								}
							}
						}
						if (contadord >= 1) {
							flagderutas = flagderutas - 1;
						}
						if (flagderutas != 1) {
							flag = 1;
						} else {
							switches2.get(0).add(switches.get(0).get(variableintermedia));
							switches2.get(0).add(switches.get(1).get(variableintermedia));
							nodoiniciointer = Integer.parseInt(switches.get(3).get(variableintermedia));
							nodoinicio = nodoiniciointer;
							nodosinter = "@" + nodoiniciointer + nodosinter;
							nodosintercompletosinicio = "@" + switches.get(1).get(variableintermedia) + "@"
									+ switches.get(0).get(variableintermedia) + nodosintercompletosinicio;
						}
						contadord++;
					}

					nodoiniciointer = nodofinal;
//					System.out.println("Nodos Intermedios inicios");
//					System.out.println(nodoiniciointer);
					contadord = 0;
					flag = 0;
					String nodosintermediofinal = "";
					while (flag == 0) {
						flagderutas = 0;
						for (int i = 0; switches.get(0).size() > i; i++) {
							if (Integer.parseInt(switches.get(2).get(i)) == nodoiniciointer) {
								flagderutas++;
								if (flagderutas == 1) {
									variableintermedia = i;
								}
							}
						}
						if (contadord >= 1) {
							flagderutas = flagderutas - 1;
						}
						if (flagderutas != 1) {
							flag = 1;
						} else {
							switches2.get(0).add(switches.get(0).get(variableintermedia));
							switches2.get(0).add(switches.get(1).get(variableintermedia));
							nodoiniciointer = Integer.parseInt(switches.get(3).get(variableintermedia));
							nodofinal = nodoiniciointer;
							nodosintermediofinal = "@" + switches.get(0).get(variableintermedia) + "@"
									+ switches.get(1).get(variableintermedia) + nodosintermediofinal;
						}
						contadord++;
					}

//					System.out.println("Nodos intermedios Final");
//					System.out.println(nodosintermediofinal);

					ArrayList<Nodo> arreglodenodos = new ArrayList<Nodo>();
					int kl = 0;
					Graph graph1 = new Graph();
					String rutas = null;

					String rutas1 = null;
					int contadorrutas;
					rutascortas.clear();
					while (kl < 1) {
						for (int i = 0; i < numeronodos; i++) {
							arreglodenodos.add(new Nodo(Integer.toString(i + 1)));
						}
						for (int i = 0; i < switches.get(0).size(); i++) {
							if (Integer.parseInt(switches.get(2).get(i)) != 0) {
								int velocidad = 0;
								try {
									String url1 = "http://127.0.0.1:8181/restconf/operational/opendaylight-inventory:nodes/node/"
											+ switches.get(1).get(i).split(":")[0] + ":"
											+ switches.get(1).get(i).split(":")[1] + "/node-connector/"
											+ switches.get(1).get(i);
									URL obj1 = new URL(url1);
									HttpURLConnection conn1 = (HttpURLConnection) obj1.openConnection();
									String userPassword1 = "admin:admin";
									conn1.setRequestMethod("GET");
									String authEncBytes1 = org.apache.commons.codec.binary.Base64
											.encodeBase64String(userPassword1.getBytes());
									conn1.setRequestProperty("Authorization", "Basic " + authEncBytes1);
									conn1.setRequestProperty("Accept", "application/json");
									InputStream content1 = conn1.getInputStream();
									BufferedReader in1 = new BufferedReader(new InputStreamReader(content1));
									String line1 = "";
//									System.out.println("Salio");
									StringBuffer result1 = new StringBuffer();
									while ((line1 = in1.readLine()) != null) {
										result1.append(line1);
									}
									line1 = in1.readLine();
									org.json.JSONObject nodosno = new org.json.JSONObject(result1.toString());
									velocidad = nodosno.getJSONArray("node-connector").getJSONObject(0)
											.getInt("flow-node-inventory:current-speed");
								} catch (Exception e) {
									// TODO: handle exception
								}
								arreglodenodos.get(Integer.parseInt(switches.get(2).get(i)) - 1).addDestination(
										arreglodenodos.get(Integer.parseInt(switches.get(3).get(i)) - 1), velocidad);
							}
						}
						graph1 = new Graph();
						for (int i = 0; i < numeronodos; i++) {
							graph1.addNode(arreglodenodos.get(i));
						}

						graph1 = Dijkstra.calculateShortestPathFromSource(graph1, arreglodenodos.get(nodofinal - 1));
						rutas = null;
						for (Nodo node : graph1.getNodes()) {
							if (Integer.parseInt(node.getName()) == nodoinicio) {
								int contador1 = 0;
								for (Nodo nodes : node.getShortestPath()) {
									if (contador1 == 0) {
										rutas = nodes.getName();
									} else {
										rutas = rutas + "@" + nodes.getName();
									}
									contador1++;
								}
							}
						}
						if (rutas != null) {
							rutas = rutas + "@" + nodoinicio;
							rutas1 = null;
							contadorrutas = 0;
							for (int j = 0; j < rutas.split("@").length - 1; j++) {
								for (int i = 0; i < switches.get(0).size(); i++) {
									if (Integer.parseInt(switches.get(2).get(i)) == Integer.parseInt(rutas.split("@")[j])) {
										if (Integer.parseInt(switches.get(3).get(i)) == Integer.parseInt(rutas.split("@")[j + 1])) {
											if (contadorrutas == 0) {
												rutas1 = (switches.get(0).get(i)) + "@" + (switches.get(1).get(i));
											} else {
												rutas1 = rutas1 + "@" + (switches.get(0).get(i)) + "@" + (switches.get(1).get(i));
											}
											switches.get(2).set(i, "0");
											switches.get(3).set(i, "0");
											contadorrutas++;
										}
									}
									if (Integer.parseInt(switches.get(3).get(i)) == Integer.parseInt(rutas.split("@")[j])) {
										if (Integer.parseInt(switches.get(2).get(i)) == Integer.parseInt(rutas.split("@")[j + 1])) {
											switches.get(2).set(i, "0");
											switches.get(3).set(i, "0");
										}
									}
								}
							}
							rutas1 = hostpip.get(ipfinal)+nodosintermediofinal + "@" + rutas1 + nodosintercompletosinicio +"@" + hostpip.get(ipinicio);
							rutascortas.add(rutas1);
							arreglodenodos.clear();
						} else {
							kl++;
						}
					}
					System.out.println("Rutas");
					System.out.println(rutascortas);
					System.out.println("Tamanio de las rutas");
					System.out.println(rutascortas.size());
					String rutanodos[]=rutascortas.get(0).split("@");

					System.out.println("Rutas split");
					System.out.println(rutanodos);
					System.out.println(rutanodos[1]);
					System.out.println(hostpip.get(ipinicio));
					int selfr=1;
					if(rutanodos[1].split(":")[1].equals(hostpip.get(ipinicio).split(":")[1])) {
						selfr=0;
					}
					System.out.println("El selector del camino es : "+selfr);
					for(int i = 0; i<rutanodos.length;) {

						if (selfr == 1) {
							NodeConnectorId ncid = new NodeConnectorId(rutanodos[i]);
							System.out.println("Entro");
//							regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
//									mensajes.getPuertoDestino(), 11, 0, n);//cambio


							System.out.println(rutanodos[i]);
							System.out.println(hostpip.get(ipinicio));
							int idetificadorlineas=0;
							if (rutanodos[i+1].equals(hostpip.get(ipinicio))) {
								System.out.println("El nodo entro ida 12");
								System.out.println(rutanodos[i]);
								idetificadorlineas=1;
//								regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//										mensajes.getPuertoFuente(), 12, 1, n);//dasd
							} else {
								System.out.println("El nodo entro ida 1");
								idetificadorlineas=0;
//								regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//										mensajes.getPuertoFuente(), 12, 0, n); //cambio
							}

//							if (rutanodos[i].equals(hostpip.get(ipinicio))) {
//								System.out.println(rutanodos[i]);
//								regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
//										mensajes.getPuertoDestino(), 11, 1, n);//dasd
//							} else {
//								regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
//										mensajes.getPuertoDestino(), 11, 0, n);//cambio
//							}
							regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
									mensajes.getPuertoDestino(), 11, idetificadorlineas, n);//cambio

							i++;

							ncid = new NodeConnectorId(rutanodos[i]);

							System.out.println(idetificadorlineas);
//							if (rutanodos[i].equals(hostpip.get(ipinicio))) {
//								System.out.println(rutanodos[i]);
//								regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//										mensajes.getPuertoFuente(), 12, 1, n); //dasd
//							} else {
//								regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//										mensajes.getPuertoFuente(), 12, 0, n);//cambio
//							}
							regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
									mensajes.getPuertoFuente(), 12, 0, n);//cambio
							i++;
						}else {
							System.out.println("El nodo i "+i);
//							System.out.println(rutanodos[i]);
							NodeConnectorId ncid = new NodeConnectorId(rutanodos[i]);
//							System.out.println(ncid);

//							regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//									mensajes.getPuertoFuente(), 12, 0, n);//cambio


							regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
									mensajes.getPuertoFuente(), 12, 0, n); //cambio
							int idetificadorlineas=0;
							if (rutanodos[i].equals(hostpip.get(ipinicio))) {
								System.out.println("El nodo entro ida 12");
								System.out.println(rutanodos[i]);
								idetificadorlineas=1;
//								regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//										mensajes.getPuertoFuente(), 12, 1, n);//dasd
							} else {
								System.out.println("El nodo entro ida 1");
								idetificadorlineas=0;
//								regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//										mensajes.getPuertoFuente(), 12, 0, n); //cambio
							}
							i++;
							ncid = new NodeConnectorId(rutanodos[i]);
//							System.out.println("El nodo i "+i);
//							System.out.println(rutanodos[i]);
							if (rutanodos[i].equals(hostpip.get(ipinicio))) {
								System.out.println("El nodo entro regreso");
								System.out.println(rutanodos[i]);
//								regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
//										mensajes.getPuertoDestino(), 11, 1, n);
								System.out.println("El nodo entro regreso");//dasd
							} else {
								System.out.println("El nodo entro regreso 11");
//								regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
//										mensajes.getPuertoDestino(), 11, 0, n); //cambio
								System.out.println("El nodo entro regreso 11 f");
							}
							regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
									mensajes.getPuertoDestino(), 11, idetificadorlineas, n); //cambio
							i++;
						}
					}
					contadorJOIN = 1;
				}

				if(ejemploint==0 ) {
//
					System.out.println("El mensaje Capable es: "+mensajes.getLongitudCampoMP_Capable());
					if(mensajes.getLongitudCampoMP_Capable()==20) {

					System.out.println("La llaves del cliente es:");
					System.out.println(mensajes.getLlaveDelEmisor());
					System.out.println(mensajes.getrawLlaveDelEmisor());
					System.out.println("La llaves del Servidor es:");

					System.out.println(mensajes.getLlaveDelReceptor());
					System.out.println(mensajes.getrawLlaveDelReceptor());
//					 AjahUtils.requireParam(data,"data");
					System.out.println("Ingreso");

					MessageDigest md=MessageDigest.getInstance("SHA-1");
					 md.update(mensajes.getrawLlaveDelReceptor(),0,mensajes.getrawLlaveDelReceptor().length);
					 byte[] bytes=md.digest();

					 byte[] bytes2= new byte[4];

					 for(int i=0;i<4;i++) {
						 bytes2[i]=bytes[i];
					 }

//					 System.out.println(bytes2);
					 BigInteger bi = new BigInteger(1,bytes2);
//					 System.out.println(bi.toString());

					BigInteger foo1 = new BigInteger(mensajes.getLlaveDelReceptor());
					byte[] array = foo1.toByteArray();
					if (array[0] == 0) {
						byte[] tmp = new byte[array.length - 1];
						System.arraycopy(array, 1, tmp, 0, tmp.length);
						array = tmp;
					}
					MessageDigest md1;
					md1 = MessageDigest.getInstance("SHA-1");
					md1.update(array, 0, array.length);
					byte[] bytes3 = md1.digest();
					byte[] nj = new byte[4];
					for (int i = 0; i < 4; i++) {
						nj[i] = bytes3[i];
					}
					BigInteger keyB32 = new BigInteger(1, nj);

					//					System.out.println(keyB32.toString());
					System.out.println(keyB32.toString());
					llaverutas.put(keyB32.toString(),
							new Rutas(rutascortas, keyB32.toString(), rutascortas.size() - 1, contadorJOIN));
				}
				}
				if (ejemploint == 1 && mensajes.getLongitudDelCampoMP_Join() == 12) {
					System.out.println();
					System.out.println("Ingreso al JOIN");
					System.out.println();
					System.out.println("El token del JOin es : " + contadorJOIN);
					System.out.println(mensajes.getJoinTokenRaw());
					System.out.println(mensajes.getJoinTokenRaw().length);
					System.out.println(mensajes.getJoinTokenString());
					System.out.println("Prueba key");
					System.out.println(llaverutas.get(mensajes.getJoinTokenString()).getrutascortas());
					System.out.println("Fin prueba");

					if (llaverutas.get(mensajes.getJoinTokenString()) != null) {
						if (llaverutas.get(mensajes.getJoinTokenString()).getconador() != 0) {

														System.out.println("Puerto Origen");
							System.out.println(mensajes.getPuertoFuente());
							System.out.println("Puerto Destino");
							System.out.println(mensajes.getPuertoDestino());
							System.out.println(rutascortas.get(contadorJOIN));

							int contadorJOIN1 = llaverutas.get(mensajes.getJoinTokenString()).getcontadorJOIN();
							System.out.println(contadorJOIN1);
							String rutanodos[] = llaverutas.get(mensajes.getJoinTokenString()).getrutascortas()
									.get(contadorJOIN1).split("@");
							System.out.println("Los nodos son del JOIN: ");
							System.out.println(llaverutas.get(mensajes.getJoinTokenString()).getrutascortas()
									.get(contadorJOIN1));
							System.out.println(rutanodos);
							//							String rutanodos[] = rutascortas.get(contadorJOIN).split("@");
//							System.out.println(rutanodos.length);
//							System.out.println("Join 1");
//							System.out.println("Join " + contadorJOIN1);
//							System.out.println(rutascortas.get(contadorJOIN1));
//							System.out.println(rutanodos.length);
							int selfr=1;
							if(rutanodos[1].split(":")[1].equals(hostpip.get(ipinicio).split(":")[1])) {
								selfr=0;
							}
							for (int i = 0; i < rutanodos.length;) {
								if(selfr==1) {
									NodeConnectorId ncid = new NodeConnectorId(rutanodos[i]);
									regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
											mensajes.getPuertoDestino(), 13 + contadorJOIN1, 0, n);//cambio
									i++;
									ncid = new NodeConnectorId(rutanodos[i]);
									regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
											mensajes.getPuertoFuente(), 14 + contadorJOIN1, 0, n);//cambio
									i++;

								}else {
									NodeConnectorId ncid = new NodeConnectorId(rutanodos[i]);
									regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
											mensajes.getPuertoFuente(), 14 + contadorJOIN1, 0, n);
									i++;
									ncid = new NodeConnectorId(rutanodos[i]);
									regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
											mensajes.getPuertoDestino(), 13 + contadorJOIN1, 0, n); //cambio
									i++;

								}
//								NodeConnectorId ncid = new NodeConnectorId(rutanodos[i]);
//								regla5tuplas(ncid, ipDestinoAnalizador, ipFuenteAnalizador, mensajes.getPuertoFuente(),
//										mensajes.getPuertoDestino(), 13 + contadorJOIN1, 0, n);
//								i++;
//								ncid = new NodeConnectorId(rutanodos[i]);
//								regla5tuplas(ncid, ipFuenteAnalizador, ipDestinoAnalizador, mensajes.getPuertoDestino(),
//										mensajes.getPuertoFuente(), 14 + contadorJOIN1, 0, n);
//								i++;
							}

							contadorJOIN1++;
							System.out.println("Prueba contador join");
							System.out.println(llaverutas.get(mensajes.getJoinTokenString()).getcontadorJOIN());
							llaverutas.get(mensajes.getJoinTokenString()).setcontadorJOIN(contadorJOIN1);
							System.out.println(llaverutas.get(mensajes.getJoinTokenString()).getcontadorJOIN());
							System.out.println("Contador total de rutas");
							System.out.println(llaverutas.get(mensajes.getJoinTokenString()).getconador());
							llaverutas.get(mensajes.getJoinTokenString())
									.setcontador(llaverutas.get(mensajes.getJoinTokenString()).getconador() - 1);
							System.out.println(llaverutas.get(mensajes.getJoinTokenString()).getconador());
						}
					}

				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}

	}

//	private  JSONObject restDatos(String conexion) {
//		JSONObject ejemplo=null;
//		try {
//			String url = conexion;
//			URL obj = new URL(url);
//			HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
//			String userPassword = "admin:admin";
//			conn.setRequestMethod("GET");
//			String authEncBytes = org.apache.commons.codec.binary.Base64
//					.encodeBase64String(userPassword.getBytes());
//			conn.setRequestProperty("Authorization", "Basic " + authEncBytes);
//			conn.setRequestProperty("Accept", "application/json");
//			InputStream content = conn.getInputStream();
//			BufferedReader in = new BufferedReader(new InputStreamReader(content));
//			String line = "";
//			System.out.println("Salio");
//			StringBuffer result = new StringBuffer();
//			while ((line = in.readLine()) != null) {
//				result.append(line);
//			}
//			line = in.readLine();
//			ejemplo = new JSONObject(result.toString());
//
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return ejemplo;
//
//	}
//	private int velocidadenlace(String enlace) {
////		JSONObject ejemplo=null;
////		StringBuffer result;
//		int velocidad=0;
//		try {
//			String url = "http://127.0.0.1:8181/restconf/operational/opendaylight-inventory:nodes/node/"+enlace.split(":")[0]+":"+enlace.split(":")[1]+"/node-connector/"+enlace;
//			URL obj = new URL(url);
//			HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
//			String userPassword = "admin:admin";
//			conn.setRequestMethod("GET");
//			String authEncBytes = org.apache.commons.codec.binary.Base64
//					.encodeBase64String(userPassword.getBytes());
//			conn.setRequestProperty("Authorization", "Basic " + authEncBytes);
//			conn.setRequestProperty("Accept", "application/json");
//			InputStream content = conn.getInputStream();
//			BufferedReader in = new BufferedReader(new InputStreamReader(content));
//			String line = "";
//			System.out.println("Salio");
//			StringBuffer result = new StringBuffer();
//			while ((line = in.readLine()) != null) {
//				result.append(line);
//			}
//			line = in.readLine();
//			JSONObject ejemplo = new JSONObject(result.toString());
//			JSONObject nodosno = ejemplo;
//			velocidad = nodosno.getJSONArray("node-connector").getJSONObject(0).getInt("flow-node-inventory:current-speed");
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return velocidad;
//	}

	private void reglasiniciocontrolador(long tipo, NodeId jk){
    	ArrayList<Action> accciones_salida = new ArrayList<Action>();
		accciones_salida.add(new ActionBuilder().setOrder(1).
				setKey(new ActionKey(2))
				.setAction(new OutputActionCaseBuilder().
				setOutputAction(new OutputActionBuilder().setMaxLength(0xffff) //100 BYTES
			    .setOutputNodeConnector(new Uri(OutputPortValues.CONTROLLER.toString())).build()).build()).build());
		 EthernetMatchBuilder ethernetMatch_constructor = new EthernetMatchBuilder()
				 .setEthernetType(new EthernetTypeBuilder().setType(new EtherType(tipo)).build());

		Match match = new MatchBuilder().setEthernetMatch(ethernetMatch_constructor.build()).build();
		FlowBuilder floodFlow = new FlowBuilder().setTableId(tabla_id).setFlowName("5e");
		 floodFlow.setId(new FlowId("Tipo "+tipo+jk.getValue()));
		 floodFlow.setMatch(match).setPriority(150).setCookie(new FlowCookie(BigInteger.valueOf(cookie_uno.getAndIncrement()))).setFlags(new FlowModFlags(false, false, false, false, false));
		 ApplyActions acciones_aplicar = new ApplyActionsBuilder()
					//TOMA DE ARGUMENTO LISTA QUE NO VARIA ImmutableList.copyOf(accciones_salida)
					.setAction(ImmutableList.copyOf(accciones_salida)).build();
				//instrucciones_acciones_aplicar SE CONFIGURA EN FUNCIÓN DE .setApplyActions(acciones_aplicar)
				Instruction instrucciones_acciones_aplicar = new InstructionBuilder().setOrder(0)
				.setInstruction(new ApplyActionsCaseBuilder()
				.setApplyActions(acciones_aplicar).build()).build();
				floodFlow.setInstructions(new InstructionsBuilder().setInstruction(ImmutableList.of(instrucciones_acciones_aplicar)).build());
				 //NodeId id_switch = InventoryUtils.getNodeId(jk);//ncid
				   //InventoryUtils.getNodeId(nodeConnectorId)
					InstanceIdentifier<Flow> flujo = InstanceIdentifier.builder(Nodes.class)
							.child(Node.class, new NodeKey(jk)).augmentation(FlowCapableNode.class)
							.child(Table.class, new TableKey((short) 0))//TABLA DE FLUJO 0
							.child(Flow.class, new FlowKey(new FlowId(floodFlow.build().getId().getValue()))).build();
					GenericTransactionUtils.writeData(dataBroker, LogicalDatastoreType.CONFIGURATION, flujo,
						floodFlow.build(), true);
    }

	private void reglasinicioDefecto(NodeId jk) {
		ArrayList<Action> accciones_salida = new ArrayList<Action>();
		accciones_salida
				.add(new ActionBuilder()
						.setOrder(1).setKey(
								new ActionKey(2))
						.setAction(new OutputActionCaseBuilder()
								.setOutputAction(new OutputActionBuilder().setMaxLength(0xffff)
										.setOutputNodeConnector(new Uri(OutputPortValues.NORMAL.toString())).build())
								.build())
						.build());
		Match match = new MatchBuilder().build();
		FlowBuilder floodFlow = new FlowBuilder().setTableId(tabla_id).setFlowName("5e");
		floodFlow.setId(new FlowId("Defecto " + jk.getValue()));
		floodFlow.setMatch(match).setPriority(100)
				.setCookie(new FlowCookie(BigInteger.valueOf(cookie_uno.getAndIncrement())))
				.setFlags(new FlowModFlags(false, false, false, false, false));
		ApplyActions acciones_aplicar = new ApplyActionsBuilder().setAction(ImmutableList.copyOf(accciones_salida))
				.build();
		Instruction instrucciones_acciones_aplicar = new InstructionBuilder().setOrder(0)
				.setInstruction(new ApplyActionsCaseBuilder().setApplyActions(acciones_aplicar).build()).build();
		floodFlow.setInstructions(
				new InstructionsBuilder().setInstruction(ImmutableList.of(instrucciones_acciones_aplicar)).build());
		InstanceIdentifier<Flow> flujo = InstanceIdentifier.builder(Nodes.class).child(Node.class, new NodeKey(jk))
				.augmentation(FlowCapableNode.class).child(Table.class, new TableKey((short) 0))
				.child(Flow.class, new FlowKey(new FlowId(floodFlow.build().getId().getValue()))).build();
		GenericTransactionUtils.writeData(dataBroker, LogicalDatastoreType.CONFIGURATION, flujo, floodFlow.build(),
				true);
	}





	private void regla5tuplas(NodeConnectorId ncid, String ipDestinoAnalizador, String ipFuenteAnalizador,
			int puertodeentrada, int puertodesalida, int selector, int selectorcontrolador, int tipoMPTCP) {
		ArrayList<Action> accciones_salida = new ArrayList<Action>();
		accciones_salida.add(new ActionBuilder().setOrder(0).setKey(new ActionKey(1))
				.setAction(new OutputActionCaseBuilder().setOutputAction(new OutputActionBuilder().setMaxLength(0xffff)// PAQUETE
																														// COMPLETO
						.setOutputNodeConnector(ncid)// PUERTO DE SALIDA
						.build()).build())
				.build());
		if (selectorcontrolador == 1) {
			accciones_salida.add(new ActionBuilder().setOrder(1).setKey(new ActionKey(2))
					.setAction(
							new OutputActionCaseBuilder().setOutputAction(new OutputActionBuilder().setMaxLength(0x64) // 100
																														// BYTES
									.setOutputNodeConnector
									// (new
									// Uri(OutputPortValues.NORMAL.toString()))

									(new Uri(OutputPortValues.CONTROLLER.toString()))// PUERTO
																						// DE
																						// SALIDA:
																						// CONTROLADOR
									.build()).build())
					.build());
		}

		FlowBuilder floodFlow = new FlowBuilder().setTableId(tabla_id).setFlowName("5e");
		floodFlow.setId(new FlowId(selector + "regla"+tipoMPTCP+puertodeentrada+puertodesalida));//+tipoMPTCP+puertodeentrada+puertodesalida
		// CON IpMatchBuilder SE PUEDE CONFIGURAR EL PROTOCOLO SOBRE IP PARA
		// HACER MATCHING (6 TCP)
		IpMatchBuilder constructor_ipmatch = new IpMatchBuilder();
		constructor_ipmatch.setIpProtocol((short) 6).build();
		// CON EthernetMatchBuilder SE PUEDE CONFIGURAR EL CAMPO TIPO ETHERNET
		// HACER MATCHING (800 IP)
		EthernetMatchBuilder ethernetMatch_constructor = new EthernetMatchBuilder()
				.setEthernetType(new EthernetTypeBuilder().setType(new EtherType((long) 0x800)).build());
		// CON AYUDA DE setInPort, setEthernetMatch Y setIpMatch LOS CUALES
		// TOMAN
		// TOMAN COMO ARGUMENTO nc.getId(), IpMatchBuilder, EthernetMatchBuilder
		// SE CREA OBJETO match
		contadorreglas++;

		Ipv4MatchBuilder ipv4matchdes = new Ipv4MatchBuilder();
		ipv4matchdes.setIpv4Destination(
				new org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.Ipv4Prefix(
						ipDestinoAnalizador + "/32"));
		ipv4matchdes.setIpv4Source(
				new org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.Ipv4Prefix(
						ipFuenteAnalizador + "/32"));
		TcpMatchBuilder tcpmatchPF = new TcpMatchBuilder();
		tcpmatchPF.setTcpSourcePort(
				new org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.PortNumber(
						puertodeentrada));
		tcpmatchPF.setTcpDestinationPort(
				new org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.PortNumber(
						puertodesalida));
		// matchBuilder.setLayer4Match(tcpmatch.build());

		// org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev100924.PortNumber("80");

		// CON AYUDA DE setInPort, setEthernetMatch Y setIpMatch LOS CUALES
		// TOMAN
		// TOMAN COMO ARGUMENTO nc.getId(), IpMatchBuilder, EthernetMatchBuilder
		// SE CREA OBJETO match
		Match match = new MatchBuilder().setEthernetMatch(ethernetMatch_constructor.build())
				.setIpMatch(constructor_ipmatch.build()).setLayer4Match(tcpmatchPF.build())
				.setLayer3Match(ipv4matchdes.build()).build();
		// Match match =new
		// MatchBuilder().setEthernetMatch(ethernetMatch_constructor.build()).build();

		// Match match = new
		// MatchBuilder().setInPort(nc.getId()).setEthernetMatch(ethernetMatch_constructor.build())
		// .setIpMatch(constructor_ipmatch.build()).build();
		// SE CONFIGURA A floodFlow EL CAMPO match CON PRIORIDAD 200
		floodFlow.setMatch(match).setHardTimeout(0).setIdleTimeout(300).setPriority(prioridad_flujo_proactivo + 100)
				.setCookie(new FlowCookie(BigInteger.valueOf(cookie_uno.getAndIncrement())))
				.setFlags(new FlowModFlags(false, false, false, false, true));// se cambio por alse el ultimo ya que en este si no se pone nada tiene un tiempo de muerte

		ApplyActions acciones_aplicar = new ApplyActionsBuilder()
				// TOMA DE ARGUMENTO LISTA QUE NO VARIA
				// ImmutableList.copyOf(accciones_salida)
				.setAction(ImmutableList.copyOf(accciones_salida)).build();
		// instrucciones_acciones_aplicar SE CONFIGURA EN FUNCIÓN DE
		// .setApplyActions(acciones_aplicar)
		Instruction instrucciones_acciones_aplicar = new InstructionBuilder().setOrder(0)
				.setInstruction(new ApplyActionsCaseBuilder().setApplyActions(acciones_aplicar).build()).build();
		// constructor_reglas_flood, RESULTADO DE LA FUNCIÓN
		// creacion_campo_matching_reglas_proactivas
		// QUE DEVUELVE UN OBJETO FlowBuilder CON SU CAMPO DE MATCHING

		// SE CONFIGURA Instructions CON
		// ImmutableList.of(instrucciones_acciones_aplicar)
		floodFlow.setInstructions(
				new InstructionsBuilder().setInstruction(ImmutableList.of(instrucciones_acciones_aplicar)).build());

		// Flow regla_recuperada = getreglas_proactivas_totales().get(g);
		// CREACIÓN instancia_flujo, PARA CREAR CAMINO DONDE SE VA A BORRAR LA
		// REGLA PROACTIVA
		NodeId id_switch = InventoryUtils.getNodeId(ncid);// ncid
		// InventoryUtils.getNodeId(nodeConnectorId)
		InstanceIdentifier<Flow> flujo = InstanceIdentifier.builder(Nodes.class)
				.child(Node.class, new NodeKey(id_switch)).augmentation(FlowCapableNode.class)
				.child(Table.class, new TableKey((short) 0))// TABLA DE FLUJO 0
				.child(Flow.class, new FlowKey(new FlowId(floodFlow.build().getId().getValue()))).build();
		// TRANSACCIÓN PARA BORRAR LA REGLA PROACTIVA REPETIDA
		GenericTransactionUtils.writeData(dataBroker, LogicalDatastoreType.CONFIGURATION, flujo, floodFlow.build(),
				true);
	}

	private void reglasinicioIPControler(short tipo , NodeId jk){
    	ArrayList<Action> accciones_salida = new ArrayList<Action>();
		accciones_salida.add(new ActionBuilder().setOrder(1).
				setKey(new ActionKey(2))
				.setAction(new OutputActionCaseBuilder().
				setOutputAction(new OutputActionBuilder().setMaxLength(0xffff) //100 BYTES
			    .setOutputNodeConnector(new Uri(OutputPortValues.CONTROLLER.toString())).build()).build()).build());
		 EthernetMatchBuilder ethernetMatch_constructor = new EthernetMatchBuilder()
				 .setEthernetType(new EthernetTypeBuilder().setType(new EtherType((long) 0x800)).build());
		 IpMatchBuilder constructor_ipmatch = new IpMatchBuilder();
		 constructor_ipmatch.setIpProtocol(tipo).build();
		Match match = new MatchBuilder().setEthernetMatch(ethernetMatch_constructor.build()).setIpMatch(constructor_ipmatch.build()).build();
		FlowBuilder floodFlow = new FlowBuilder().setTableId(tabla_id).setFlowName("5e");
		 floodFlow.setId(new FlowId("Tipo "+tipo+jk.getValue()));
		 floodFlow.setMatch(match).setPriority(150).setCookie(new FlowCookie(BigInteger.valueOf(cookie_uno.getAndIncrement()))).setFlags(new FlowModFlags(false, false, false, false, false));
		 ApplyActions acciones_aplicar = new ApplyActionsBuilder()
					//TOMA DE ARGUMENTO LISTA QUE NO VARIA ImmutableList.copyOf(accciones_salida)
					.setAction(ImmutableList.copyOf(accciones_salida)).build();
				//instrucciones_acciones_aplicar SE CONFIGURA EN FUNCIÓN DE .setApplyActions(acciones_aplicar)
				Instruction instrucciones_acciones_aplicar = new InstructionBuilder().setOrder(0)
				.setInstruction(new ApplyActionsCaseBuilder()
				.setApplyActions(acciones_aplicar).build()).build();
				floodFlow.setInstructions(new InstructionsBuilder().setInstruction(ImmutableList.of(instrucciones_acciones_aplicar)).build());
				 //NodeId id_switch = InventoryUtils.getNodeId(jk);//ncid
				   //InventoryUtils.getNodeId(nodeConnectorId)
					InstanceIdentifier<Flow> flujo = InstanceIdentifier.builder(Nodes.class)
							.child(Node.class, new NodeKey(jk)).augmentation(FlowCapableNode.class)
							.child(Table.class, new TableKey((short) 0))//TABLA DE FLUJO 0
							.child(Flow.class, new FlowKey(new FlowId(floodFlow.build().getId().getValue()))).build();
			         //TRANSACCIÓN PARA BORRAR LA REGLA PROACTIVA REPETIDA
					GenericTransactionUtils.writeData(dataBroker, LogicalDatastoreType.CONFIGURATION, flujo,
						floodFlow.build(), true);
    }


	@Override
	public void onNodeConnectorRemoved(NodeConnectorRemoved arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onNodeConnectorUpdated(NodeConnectorUpdated arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onNodeRemoved(NodeRemoved arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onNodeUpdated(NodeUpdated arg0) {
		// TODO Auto-generated method stub
		NodeId jk=arg0.getId();
		reglasinicioIPControler((short) 0x06, jk);
//		System.out.println("Entro el switch");
//		System.out.println(arg0);
//		System.out.println(jk.toString());
//		reglasiniciocontrolador(0x0806, jk);
//		reglasinicioIPControler((short) 0x06, jk);

	}

//	@Override
//	public void onNodeConnectorRemoved(NodeConnectorRemoved arg0) {
//		// TODO Auto-generated method stub
//
//	}
//
//	@Override
//	public void onNodeConnectorUpdated(NodeConnectorUpdated puerto_obtenido) {
//
//	}
//
//	@Override
//	public void onNodeRemoved(NodeRemoved arg0) {
//		// TODO Auto-generated method stub
//	}
//
//	@Override
//	public void onNodeUpdated(NodeUpdated switch_obtenido) {
//		// TODO Auto-generated method stub
//
//	}

	/*
	 * NOTIFICACION QUE DECODIFICA LOS PAQUETES IPV4 QUE ENVIA EL SWITCH AL
	 * CONTROLADOR
	 */

	/*
	 * MÉTODO QUE IMPLEMENTA FLUJO REACTIVO, BASADO EN PATH-ID SWITCH, PUERTO
	 * INGRESO, PUERTO SALIDA, IP DESTINO
	 */
	// FUNCION creador_instancia_flujo, CREA RUTA EN EL DATA STORE EN
	// node/table, EN opendaylight-inventory

	/*
	 * CREACIÓN DE SETTERS Y GETTERS EN VARIABLES QUE SE USARÁN EN OTRAS CLASES
	 * COMO ANALIZADORMPTCPMODULE
	 */


}