package org.opendaylight.analizador.epn.analizadormptcp.impl;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Nodo {
	private String name;

	private LinkedList<Nodo> shortestPath = new LinkedList<>();

	private Integer distance = Integer.MAX_VALUE;

	private Map<Nodo, Integer> adjacentNodes = new HashMap<>();

	public Nodo(String name) {
		this.name = name;
	}

	public void addDestination(Nodo destination, int distance) {
		adjacentNodes.put(destination, distance);
	}

	public void delNode() {
//		adjacentNodes.remove(key)
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<Nodo, Integer> getAdjacentNodes() {
		return adjacentNodes;
	}

	public void setAdjacentNodes(Map<Nodo, Integer> adjacentNodes) {
		this.adjacentNodes = adjacentNodes;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public List<Nodo> getShortestPath() {
		return shortestPath;
	}

	public void setShortestPath(LinkedList<Nodo> shortestPath) {
		this.shortestPath = shortestPath;
	}

}
