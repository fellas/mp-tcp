package org.opendaylight.analizador.epn.analizadormptcp.impl;


import org.opendaylight.analizador.epn.utils.PacketParsingUtils;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeId;

public class MensajesMP_TCP {
	// UNA VEZ QUE SE DETERMINA QUE EL MENSAJE ES MP-TCP, EN LA CLASE
	// "Analizadormptcp"
	// SE REALIZA UN LLAMADO A ESTA CLASE, DONDE SE PROCEDE CON LA DECODIFICACÓN
	// DE CADA
	// SUBTIPO DE MENSAJE MP-TCP.
	// LA VARIABLE "DatosSubtipoMP_TCP" PERMITE ALMACENAR TODA LA INFORMACIÓN
	// DEL MENSAJE
	// MP-TCP ANALIZADO.

	public String DatosSubtipoMP_TCP = null;
	public String SubtipoMPTCPString;
	public String PuertoDestino;
	public String PuertoFuente;
	public String LlaveDelEmisor;
	public byte LongitudCampoMP_Capable;
	public String LlaveDelReceptor;
	public byte LongitudDelCampoMP_Join;
	public byte[] JoinTokenRaw;
	public String JoinTokenString;
	public byte[] Capable20Raw;
	public byte[] Capable20Raw2;

	public byte[] getJoinTokenRaw() {
		return JoinTokenRaw;
	}
	public String getJoinTokenString() {
		return JoinTokenString;
	}

	public byte getLongitudDelCampoMP_Join() {
		return LongitudDelCampoMP_Join;
	}

	public byte getLongitudCampoMP_Capable() {
		return LongitudCampoMP_Capable;
	}

	public String getLlaveDelReceptor() {
		return LlaveDelReceptor;
	}
	public byte[] getrawLlaveDelReceptor() {
		return Capable20Raw;
	}

	public String getLlaveDelEmisor(){
		return LlaveDelEmisor;
	}

	public byte[] getrawLlaveDelEmisor(){
		return Capable20Raw2;
	}

	// EL MÉTODO "iniciar" TIENE COMO ARGUMENTOS A VARIABLES PÚBLICAS DE LA
	// CLASE
	// "Analizadormptcp", PARA REALIZAR EL PROCESO DE DECODIFICACÓN DE MENSAJES
	// MP-TCP
	// QUE LLEGUEN A ESTA CLASE.
	public String getDatosSubtipoMP_TCP() {
		return DatosSubtipoMP_TCP;
	}

	public Integer getPuertoDestino() {
		return Integer.parseInt(PuertoDestino);
	}

	public Integer getPuertoFuente() {
		return Integer.parseInt(PuertoFuente);
	}

	public String getSubtipoMPTCPString() {
		return SubtipoMPTCPString;
	}

	public void iniciar(byte[] OpcionesTCPRaw, int Puntero, byte[] PayloadTramaCapturada, int CabeceraIPVariable,
			final String MacFuenteAnalizador, final String MacDestinoAnalizador, final String IPFuenteAnalizador,
			final String IPDestinoAnalizador, final NodeId IdentificadorDelNodo) {

		// SE VA EXTRAER EL TERCER BYTE DEL ARREGLO DE BYTES DEL MENSAJE MP-TCP
		// QUE
		// LLEGUE AL ANALIZADOR
		byte SubtipoMPTCPByte = OpcionesTCPRaw[Puntero + 2];
		// SE REALIZARÁ UN DESPLAZAMIENTO DE BITS A LA DERECHA PARA OBTENER LOS
		// 4 BITS MAS SIGNIFICATIVOS, QUE SON LOS QUE DETERMINAN EL SUBTIPO DE
		// MENSAJE MP-TCP
		int SubtipoMPTCPEntero = (SubtipoMPTCPByte) >> 4;
		// SE OBTIENE UN VALOR TIPO STRING DE UN ENTERO
		SubtipoMPTCPString = Integer.toString(SubtipoMPTCPEntero);
		// PARA OBTENER EL PUERTO FUENTE Y PUERTO DESTINO, EXTRAEMOS LOS BYTES
		// QUE
		// FORMAN DICHOS PUERTOS A TRAVÉS DEL MÉTODO "extractPuertoSrc"
		byte[] PuertoSrcRawAnalizador = PacketParsingUtils.extraerPuertoSrc(PayloadTramaCapturada, CabeceraIPVariable);
		// SE OBTIENE UN VALOR ENTERO DEL ARREGLO DE BYTES CON EL MÉTODO
		// "extract2B_reduccion" DEFINIDO EN LA CLASE "PacketParsingUtils"
		PuertoFuente = PacketParsingUtils.extraer2B_reduccion(PuertoSrcRawAnalizador);
		// SE ANADIRÁ LAS VARIABLE OBTENIDA TIPO STRING A VARIABLE DE TIPO
		// STRING
		// "DatosSubtipoMP_TCP".
		DatosSubtipoMP_TCP = "PUERTO FUENTE:		" + PuertoFuente;
		// SE REALIZA EL MISMO PROCESO DETALLADO ANTERIORMENTE AHORA CON EL
		// PUERTO DESTINO
		byte[] PuertoDstRawAnalizador = PacketParsingUtils.extraerPuertoDest(PayloadTramaCapturada, CabeceraIPVariable);
		PuertoDestino = PacketParsingUtils.extraer2B_reduccion(PuertoDstRawAnalizador);
		DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "PUERTO DESTINO:		" + PuertoDestino;

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// CAPABLE
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// MP-TCP//////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// SE DETERMINA SI EL MENSAJE RECIBIDO ES DEL SUBTIPO MP_CAPABLE
		if (SubtipoMPTCPEntero == 0) {
			// TODA LA INFORMACIÓN DECODIFICADA DE LOS CAMPOS DEL MENSAJE
			// MP_CAPABLE SE
			// ALMACENARA EN LA VARIABLE DE TIPO STRING "DatosSubtipoMP_TCP"
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CAPABLE MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;
			// SE EXTRAE Y DECODIFICA EL CAMPO VERSIÓN MP-TCP.
			byte VersionMPTCPByte = OpcionesTCPRaw[Puntero + 2];
			int VersionMPTCPEntero = (VersionMPTCPByte & 0xf);
			String VersionMPTCPString = Integer.toString(VersionMPTCPEntero);
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VERSIÓN DE MP-TCP:		" + VersionMPTCPString;
			// SE EXTRAE Y DECODIFICA EL CAMPO LONGITUD DEL MENSAJE MP_CAPABLE
			LongitudCampoMP_Capable = OpcionesTCPRaw[Puntero + 1];
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "LONGITUD DEL MENSAJE CAPABLE MP-TCP:	"
					+ LongitudCampoMP_Capable;
			byte BanderasMP_CapableByte = OpcionesTCPRaw[Puntero + 3];
			String BanderasMP_CapableString = Integer.toBinaryString(BanderasMP_CapableByte);

			// SE EXTRAE LA INFORMACIÓN DE LAS BANDERAS DEL MENSAJE DEL SUBTIPO
			// CAPABLE MP-TCP,
			// DONDE SE DETERMINA SI SE SOLICITA EL USO DE CHECKSUM Y LOS
			// CODIGOS DE AUTENTICACIÓN
			// HMAC_SHA1. PARA REALIZARLO ES NECESARIO ANALIZAR DATOS A NIVEL DE
			// BIT, POR LO QUE
			// SE TRASNFORMA AL BYTE "BanderasMP_CapableByte" A TIPO CHAR
			if (BanderasMP_CapableByte == 1) {
				char USE_HMAC_SHA1 = 1;
				char CHECKSUM_REQUERIDO = 0;
				// ANÁLISIS DE LOS BITS DE BANDERAS PARA EL MENSAJE DEL SUBTIPO
				// CAPABLE MP-TCP.
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE CAPABLE MP-TCP";
				if (CHECKSUM_REQUERIDO == 0) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	0xxx xxxx:	NO REQUIERE CHECKSUM";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	1xxx xxxx:	SI REQUIERE CHECKSUM";
				}

				if (USE_HMAC_SHA1 == 0) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx0:	NO USA HMAC-SHA1";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx1:	SI USA HMAC-SHA1";
				}
			} else {
				char ArregloBanderaMP_Capable[] = BanderasMP_CapableString.toCharArray();
				char USE_HMAC_SHA1 = ArregloBanderaMP_Capable[31];
				char CHECKSUM_REQUERIDO = ArregloBanderaMP_Capable[24];
				// ANÁLISIS DE LOS BITS DE BANDERAS PARA EL MENSAJE DEL SUBTIPO
				// CAPABLE MP-TCP
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE CAPABLE MP-TCP";
				if (CHECKSUM_REQUERIDO == 0) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	0xxx xxxx:	NO REQUIERE CHECKSUM";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	1xxx xxxx:	SI REQUIERE CHECKSUM";
				}

				if (USE_HMAC_SHA1 == 0) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx0:	NO USA HMAC-SHA1";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx1:	SI USA HMAC-SHA1";
				}
			}
			// DETERMINACION DE LA LLAVE DEL EMISOR, SI LA LONGITUD DEL MENSAJE
			// MP_CAPABLE ES 12
			if (LongitudCampoMP_Capable == 12) {
				// EXTRACCION DEL ARREGLO DE BYTES DEL CAMPO LLAVE DEL EMISOR
				// DEL MENSAJE RECIBIDO
				byte[] Capable12Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4);
				// PROCESO DE DETERMINACION DE LA LLAVE DEL EMISOR TIPO STRING
				// CON EL METODO
				// .extraer8B_reduccion DE LA CLASE PacketParsingUtils
				LlaveDelEmisor = PacketParsingUtils.extraer8B_reduccion(Capable12Raw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + " LLAVE DEL EMISOR:		" + LlaveDelEmisor;
			}
			// DETERMINACION DE LA LLAVE DEL EMISOR Y RECEPTOR, SI LA LONGITUD
			// DEL MENSAJE
			// MP_CAPABLE ES 20
			if (LongitudCampoMP_Capable == 20) {
				Capable20Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4);
				LlaveDelEmisor = PacketParsingUtils.extraer8B_reduccion(Capable20Raw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + " LLAVE DEL EMISOR:		" + LlaveDelEmisor;

				Capable20Raw2 = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4 + 8);
				LlaveDelReceptor = PacketParsingUtils.extraer8B_reduccion(Capable20Raw2);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + " LLAVE DEL RECEPTOR:		" + LlaveDelReceptor;
			}
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// JOIN
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// MP-TCP////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// SE DETERMINA SI EL MENSAJE RECIBIDO ES DEL SUBTIPO MP_JOIN
		if (SubtipoMPTCPEntero == 1) {
			// TODA LA INFORMACIÓN DECODIFICADA DE LOS CAMPOS DEL MENSAJE
			// MP_JOIN SE
			// ALMACENARA EN LA VARIABLE DE TIPO STRING "DatosSubtipoMP_TCP"
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "JOIN MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;
			// DETERMINACIÓN DE LA LONGITUD DEL MENSAJE MP_JOIN
			LongitudDelCampoMP_Join = OpcionesTCPRaw[Puntero + 1];
			// SI LA LONGITUD ES 12 BYTES, SE REALIZARÁ EL PROCESO DE
			// DECODIFICACION DEL
			// PRIMER MENSAJE MP_JOIN
			if (LongitudDelCampoMP_Join == 12) {
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "PRIMER MENSAJE DE JOIN MP-TCP";
				// EXTRACCIÓN Y DETERMINACIÓN DEL ESTADO DEL BIT DE BANDERA
				// BACKUP SELECCIONADO
				byte Backup_MPTCPByte = OpcionesTCPRaw[Puntero + 2];
				// SELECCION DE LOS BITS MENOS SIGNIFICATIVOS
				int Backup_MPTCPEntero = (Backup_MPTCPByte & 0xf);
				// ANÁLISIS DE LOS BITS DE BANDERAS PARA EL MENSAJE DEL SUBTIPO
				// CAPABLE MP-TCP
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DE MENSAJE JOIN MP-TCP";
				if (Backup_MPTCPEntero == 1) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx1:	BACKUP SELECCIONADO";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx0:	BACKUP NO SELECCIONADO";
				}
				// DETERMINACIÓN DEL VALOR IDENTIFICADOR DE DIRECCIÓN
				byte Identificador_direccion_MPTCPByte = OpcionesTCPRaw[Puntero + 3];
				// TRANSFORMACION DEL BYTE ANTERIOR A ENTERO
				int Identificador_direccion_MPTCPEntero = (Identificador_direccion_MPTCPByte & 0xff);
				// TRANFORMACION DEL ENTERO ANTERIOR A STRING
				String Identificador_direccion_MPTCPString = Integer.toString(Identificador_direccion_MPTCPEntero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + " IDENTIFICADOR DE DIRECCIÓN:			"
						+ Identificador_direccion_MPTCPString;
				// DETERMINACIÓN DEL VALOR TOKEN DEL RECEPTOR
				JoinTokenRaw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4);
				JoinTokenString = PacketParsingUtils.extraer4B_reduccion(JoinTokenRaw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "TOKEN DEL RECEPTOR:		" + JoinTokenString;
				// DETERMINACIÓN DEL NÚMERO ALEATORIO DEL EMISOR
				byte[] NumeroAleatorioJoinRaw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4 + 4);
				String NumeroAleatorioJoinString = PacketParsingUtils.extraer4B_reduccion(NumeroAleatorioJoinRaw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "NÚMERO ALEATORIO DEL EMISOR:		"
						+ NumeroAleatorioJoinString;
			}
			// SI LA LONGITUD ES 16 BYTES, ES EL SEGUNDO MENSAJE DEL SUBTIPO
			// MP_JOIN
			if (LongitudDelCampoMP_Join == 16) {
				// DECODIFICACIÓN DE INFORMACIÓN COMO: BIT DE BACKUP, ADDRESS
				// ID,
				// HMAC TRUNCADO DEL EMISOR Y NÚMERO ALEATORIO DEL EMISOR.
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SEGUNDO MENSAJE DE JOIN MP-TCP";
				byte Backup_MPTCPByte = OpcionesTCPRaw[Puntero + 2];
				int Backup_MPTCPEntero = (Backup_MPTCPByte & 0xf);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE JOIN MP-TCP";
				if (Backup_MPTCPEntero == 1) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx1:	BACKUP SELECCIONADO";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	xxxx xxx0:	BACKUP NO SELECCIONADO";
				}
				// INDENTIFICADOR DE DIRECCION
				byte Address_ID_MPTCPByte = OpcionesTCPRaw[Puntero + 3];
				int Address_ID_MPTCPEntero = (Address_ID_MPTCPByte & 0xff);
				String Address_ID_MPTCPString = Integer.toString(Address_ID_MPTCPEntero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + " INDENTIFICADOR DE DIRECCION:	"
						+ Address_ID_MPTCPString;
				// HMAC TRUNCADO DEL EMISOR(64bits)
				byte[] HMAC_TRUNCADO_JOINRaw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4);
				String HMAC_TRUNCADO_JOINString = PacketParsingUtils.extraer8B_reduccion(HMAC_TRUNCADO_JOINRaw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HMAC TRUNCADA DEL EMISOR:		"
						+ HMAC_TRUNCADO_JOINString;
				// NÚMERO ALEATORIO DEL EMISOR(32bits)
				byte[] NumeroAleatorioJoinRaw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4 + 8);
				String NumeroAleatorioJoinString = PacketParsingUtils.extraer4B_reduccion(NumeroAleatorioJoinRaw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "NÚMERO ALEATORIO DEL EMISOR:		"
						+ NumeroAleatorioJoinString;
			}
			// SI LA LONGITUD ES 24 BYTES, ES EL TERCER MENSAJE DEL SUBTIPO
			// MP_JOIN
			if (LongitudDelCampoMP_Join == 24) {
				// DECODIFICACIÓN DE LA INFORMACIÓN DEL HMAC TRUNCADO DEL EMISOR
				// QUE SE DIVIDE EN 5 VALORES DONDE CADA UNO DE ELLOS REPRESENTA
				// A 4 BYTES DEL UN TOTAL DE 2O BYTES QUE FORMAN DICHO VALOR.
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "TERCER MENSAJE DE JOIN MP-TCP";
				byte[] HMAC_JoinRaw1 = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4);
				String HMACString1 = PacketParsingUtils.extraer4B_reduccion(HMAC_JoinRaw1);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HMAC DEL EMISOR(1):		" + HMACString1;
				byte[] HMAC_JoinRaw2 = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 8);
				String HMACString2 = PacketParsingUtils.extraer4B_reduccion(HMAC_JoinRaw2);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HMAC DEL EMISOR(2):		" + HMACString2;
				byte[] HMAC_JoinRaw3 = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 12);
				String HMACString3 = PacketParsingUtils.extraer4B_reduccion(HMAC_JoinRaw3);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HMAC DEL EMISOR(3):		" + HMACString3;
				byte[] HMAC_JoinRaw4 = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 16);
				String HMACString4 = PacketParsingUtils.extraer4B_reduccion(HMAC_JoinRaw4);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HMAC DEL EMISOR(4):		" + HMACString4;
				byte[] HMAC_JoinRaw5 = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 20);
				String HMACString5 = PacketParsingUtils.extraer4B_reduccion(HMAC_JoinRaw5);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HMAC DEL EMISOR(5):		" + HMACString5;
			}
		}

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// DSS
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// MPTCP//////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		if (SubtipoMPTCPEntero == 2) {
			// PARA DETERMINAR SI ES UN MENSAJE DEL SUBTIPO DSS MP-TCP SE
			// REALIZARÁ UNA COMPARACIÓN ENTRE
			// LA VARIABLE DE TIPO ENTERO "SubtipoTCPEntero" Y EL ENTERO "2" ,
			// SI SON IGUALES, SE AÑADIRÁ
			// INFORMACIÓN DE ESTE SUBTIPO DE MENSAJE A LA VARIABLE DE TIPO
			// STRING "DatosSubtipoMP_TCP".

			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DSS MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;

			// INICIALMENTE SE EXTRAERÁ EL BYTE DE BANDERAS PARA EL MENSAJE DEL
			// SUBTIPO DSS MP-TCP, LUEGO
			// SE TRANSFORMA DICHO BYTE A TIPO CHAR PARA PODER ANALIZAR BIT A
			// BIT, Y EN FUNCIÓN DE LA LONGITUD
			// DE LA LOS BITS PRESENTES EN LA BANDERA SE REALIZARÁ UN ANÁLISIS
			// DIFERENTE.
			byte Banderas_DSSByte = OpcionesTCPRaw[Puntero + 3];
			String Banderas_DSSString = Integer.toBinaryString(Banderas_DSSByte);
			char Banderas_DSSChar[] = Banderas_DSSString.toCharArray();
			int Longitud_BanderaDSSEntero = Banderas_DSSString.length();
			// SI EL NÚMERO DE BITS DE LA BANDERA DEL MENSAJE MP_DSS ES 5, SE
			// PROCEDE A REALIZAR
			// EL ANÁLISIS PRESENTADO A CONTINUACIÓN. CON ESTO SE DETERMINARÁ LA
			// PRESENCIA O AUSENCIA DE
			// INFORMACIÓN REALACIONADA MENSAJE DEL SUBTIPO MP_DSS.
			if (Longitud_BanderaDSSEntero == 5) {
				int UNOEntero = 1;
				String UNOString = Integer.toBinaryString(UNOEntero);
				char UNOChar[] = UNOString.toCharArray();
				int flag5 = Banderas_DSSChar[4];
				int flag4 = Banderas_DSSChar[3];
				int flag3 = Banderas_DSSChar[2];
				int flag2 = Banderas_DSSChar[1];
				int flag1 = Banderas_DSSChar[0];

				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE DSS MP-TCP";
				if (flag5 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx1:	SI HAY ACK";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx0:	NO HAY ACK";
				}
				if (flag4 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx1x:	ACK(8 BYTES)";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx0x:	NO HAY ACK(8 BYTES)";
				}
				if (flag3 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x1xx:	Si HAY DSN/SSN/DLL/CHECKSUM";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x0xx:	NO HAY DSN/SSN/DLL/CHECKSUM";
				}
				if (flag2 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 1xxx:	DSN(8 BYTES)";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
				}
				if (flag1 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---1 xxxx:	Si HAY DATA FIN";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				}

				// EN FUNCIÓN DEL LOS 5 BITS PRESENTES EN ESTE BYTE DE BANDERAS
				// SE DETERMINAN EL TIPO DE
				// INFORMACIÓN PRESENTE EN ESTE MENSAJE, YA SEA PARA EXTRAER
				// INFORMACIÓN COMO ACK, DATA
				// SEQUENCE NUMBER, SUBFLOW SEQUENCE NUMBER, DATA-LEVEL LENGHT Y
				// CHECKSUM, SE NECESITAN
				// DE LOS MÉTODOS DE LA CLASE "PacketParsingUtils", QUE SE
				// PRESENTAN A CONTINUACIÓN:
				if (flag5 == UNOChar[0]) {
					if (flag4 == UNOChar[0]) {
						// VALOR DE ACK CON 8 BYTES
						byte[] ACK8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 4);
						String ACK8String = PacketParsingUtils.extraer8B_reduccion(ACK8Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(8 BYTES):			" + ACK8String;
						if (flag3 == UNOChar[0]) {
							if (flag2 == UNOChar[0]) {
								// DATA SEQUENCE NUMBER (8 BYTES)
								byte[] DSN8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 12);
								String DSN8String = PacketParsingUtils.extraer8B_reduccion(DSN8Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(8 BYTES):	"
										+ DSN8String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 20);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 24);
								String DLL_2String = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLL_2String;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 26);
								String CS_2String = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM(2 BYTES):		" + CS_2String;
							} else {
								// DATA SEQUENCE NUMBER (8 BYTES)
								byte[] DSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 12);
								String DSN4String = PacketParsingUtils.extraer4B_reduccion(DSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(4 BYTES):	"
										+ DSN4String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 16);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 20);
								String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLLString;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 22);
								String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM(2 BYTES):		" + CSString;
							}
						}
					} else {
						// VALOR DE ACK CON 4 BYTES
						byte[] ACK4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 4);
						String ACK4String = PacketParsingUtils.extraer4B_reduccion(ACK4Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(4 BYTES):			" + ACK4String;
						if (flag3 == UNOChar[0]) {
							if (flag2 == UNOChar[0]) {
								// DATA SEQUENCE NUMBER (8 BYTES)
								byte[] DSN8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 8);
								String DSN8String = PacketParsingUtils.extraer8B_reduccion(DSN8Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(8 BYTES):	"
										+ DSN8String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 16);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 20);
								String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLLString;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 22);
								String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		"
										+ CSString;
							} else {
								// VALOR DSN CON 4 BYTES
								byte[] DSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 8);
								String DSN4String = PacketParsingUtils.extraer4B_reduccion(DSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(4 BYTES):	"
										+ DSN4String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 12);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 16);
								String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLLString;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 18);
								String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		"
										+ CSString;
							}
						}
					}
				}
			}
			// SI LA LONGUTUD DE LOS BITS DE LA BANDERA ES 4 BITS SE PROCEDE A
			// REALIZAR EL ANÁLISIS
			// PRESENTADO A CONTINUACIÓN:
			if (Longitud_BanderaDSSEntero == 4) {
				int UNOEntero = 1;
				String UNOString = Integer.toBinaryString(UNOEntero);
				char UNOChar[] = UNOString.toCharArray();
				int flag4 = Banderas_DSSChar[3];
				int flag3 = Banderas_DSSChar[2];
				int flag2 = Banderas_DSSChar[1];
				int flag1 = Banderas_DSSChar[0];

				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE DSS MP-TCP";
				if (flag4 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx1:	SI HAY ACK";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx0:	NO HAY ACK";
				}
				if (flag3 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx1x:	ACK(8 BYTES)";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx0x:	NO HAY ACK(8 BYTES)";
				}
				if (flag2 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x1xx:	Si HAY DSN/SSN/DLL/CHECKSUM";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x0xx:	NO HAY DSN/SSN/DLL/CHECKSUM";
				}
				if (flag1 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 1xxx:	DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				}

				// EN FUNCIÓN DEL LOS 4 BITS PRESENTES EN ESTE BYTE DE BANDERAS
				// SE DETERMINA EL
				// TIPO DE INFORMACIÓN PRESENTE EN ESTE MENSAJE, YA SE PARA
				// EXTRAER INFORMACÓN COMO ACK,
				// DATA SEQUENCE NUMBER, SUBFLOW SEQUENCE NUMBER,DATA-LEVEL
				// LENGHT Y CHECKSUM, CON AYUDA
				// DE LOS MÉTODOS DE LA CLASE "PacketParsingUtils", QUE REALIZA
				// A CONTINUACIÓN:
				if (flag4 == UNOChar[0]) {
					if (flag3 == UNOChar[0]) {
						// VALOR DE ACK (8 BYTES)
						byte[] ACK8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 4);
						String ACK8String = PacketParsingUtils.extraer8B_reduccion(ACK8Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(8 BYTES):			" + ACK8String;
						if (flag2 == UNOChar[0]) {
							if (flag1 == UNOChar[0]) {
								// DATA SEQUENCE NUMBER (8 BYTES)
								byte[] DSN8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 12);
								String DSN8String = PacketParsingUtils.extraer8B_reduccion(DSN8Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(8 BYTES):	"
										+ DSN8String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 20);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 24);
								String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLLString;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 26);
								String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		"
										+ CSString;
							} else {
								// VALOR DSN (4 BYTES)
								byte[] DSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 12);
								String DSN4String = PacketParsingUtils.extraer4B_reduccion(DSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(4 BYTES):	"
										+ DSN4String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 16);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 20);
								String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLLString;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 22);
								String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		"
										+ CSString;
							}
						}
					} else {
						// VALOR DE ACK (4 BYTES)
						byte[] ACK4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 4);
						String ACK4String = PacketParsingUtils.extraer4B_reduccion(ACK4Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(8 BYTES):			" + ACK4String;
						if (flag2 == UNOChar[0]) {
							if (flag2 == UNOChar[0]) {
								// DATA SEQUENCE NUMBER (8 BYTES)
								byte[] DSN8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 8);
								String DSN8String = PacketParsingUtils.extraer8B_reduccion(DSN8Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(8 BYTES):	"
										+ DSN8String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 16);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 20);
								String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLLString;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 22);
								String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		"
										+ CSString;
							} else {
								// VALOR DSN (4 BYTES)
								byte[] DSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 8);
								String DSN4String = PacketParsingUtils.extraer4B_reduccion(DSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(4 BYTES):	"
										+ DSN4String;
								// SUBFLOW SEQUENCE NUMBER (4 BYTES)
								byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 12);
								String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
										+ SSN4String;
								// DATA-LEVEL LENGHT (2 BYTES)
								byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 16);
								String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	"
										+ DLLString;
								// CHECKSUM (2 BYTES)
								byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
										Puntero + 18);
								String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
								DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		"
										+ CSString;
							}
						}
					}
				}
			}
			// SI LA LONGUTUD DE LOS BITS DE LA BANDERA ES 3 BITS SE PROCEDE A
			// REALIZAR EL ANÁLISIS
			// PRESENTADO A CONTINUACIÓN:
			if (Longitud_BanderaDSSEntero == 3) {
				int UNOEntero = 1;
				String UNOString = Integer.toBinaryString(UNOEntero);
				char UNOChar[] = UNOString.toCharArray();
				int flag3 = Banderas_DSSChar[2];
				int flag2 = Banderas_DSSChar[1];
				int flag1 = Banderas_DSSChar[0];

				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE DSS MP-TCP";
				if (flag3 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx1:	SI HAY ACK";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx0:	NO HAY ACK";
				}
				if (flag2 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx1x:	ACK(8 BYTES)";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx0x:	NO HAY ACK(8 BYTES)";
				}
				if (flag1 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x1xx:	SI DSN/SSN/DLL/CHECKSUM";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x0xx:	NO HAY DSN/SSN/DLL/CHECKSUM";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				}
				// EN FUNCIÓN DEL LOS 3 BITS PRESENTES EN ESTE BYTE DE BANDERAS
				// SE DETERMINA EL
				// TIPO DE INFORMACIÓN PRESENTE EN ESTE MENSAJE, YA SE PARA
				// EXTRAER INFORMACÓN COMO ACK,
				// DATA SEQUENCE NUMBER, SUBFLOW SEQUENCE NUMBER,DATA-LEVEL
				// LENGHT Y CHECKSUM, CON AYUDA
				// DE LOS MÉTODOS DE LA CLASE "PacketParsingUtils", QUE SE
				// REALIZA A CONTINUACIÓN:

				if (flag3 == UNOChar[0]) {
					if (flag2 == UNOChar[0]) {
						// VALOR DE ACK (8 BYTES)
						byte[] ACK8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 4);
						String ACK8String = PacketParsingUtils.extraer8B_reduccion(ACK8Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(8 BYTES):			" + ACK8String;
						// VALOR DATA SEQUENCE NUMBER ( 4 BYTES)
						byte[] DSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 12);
						String DSN4String = PacketParsingUtils.extraer4B_reduccion(DSN4Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(4 BYTES):	" + DSN4String;
						// SUBFLOW SEQUENCE NUMBER (4 BYTES)
						byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 16);
						String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
								+ SSN4String;
						// DATA-LEVEL LENGHT (2 BYTES)
						byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 20);
						String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	" + DLLString;
						// CHECKSUM (2 BYTES)
						byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 22);
						String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		" + CSString;
					} else {
						// VALOR DE ACK (4 BYTES)
						byte[] ACK4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 4);
						String ACK4String = PacketParsingUtils.extraer4B_reduccion(ACK4Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(4 BYTES):			" + ACK4String;
						// VALOR DATA SEQUENCE NUMBER (4 BYTES)
						byte[] DSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 8);
						String DSN4String = PacketParsingUtils.extraer4B_reduccion(DSN4Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(4 BYTES):	" + DSN4String;
						// SUBFLOW SEQUENCE NUMBER (4 BYTES)
						byte[] SSN4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 12);
						String SSN4String = PacketParsingUtils.extraer4B_reduccion(SSN4Raw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBFLOW SEQUENCE NUMBER(4 BYTES):	"
								+ SSN4String;
						// DATA-LEVEL LENGHT (2 BYTES)
						byte[] DLLRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 16);
						String DLLString = PacketParsingUtils.extraer2B_reduccion(DLLRaw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA-LEVEL LENGHT(2 BYTES):	" + DLLString;
						// CHECKSUM (2 BYTES)
						byte[] CSRaw = PacketParsingUtils.extraer2B(PayloadTramaCapturada, CabeceraIPVariable,
								Puntero + 18);
						String CSString = PacketParsingUtils.extraer2B_reduccion(CSRaw);
						DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "CHECKSUM (2 BYTES):		" + CSString;
					}
				}
			}
			// SI LA LONGUTUD DE LOS BITS DE LA BANDERA ES 2 BITS SE PROCEDE A
			// REALIZAR EL ANÁLISIS
			// PRESENTADO A CONTINUACIÓN:

			if (Longitud_BanderaDSSEntero == 2) {
				int UNOEntero = 1;
				String UNOString = Integer.toBinaryString(UNOEntero);
				char UNOChar[] = UNOString.toCharArray();

				int flag2 = Banderas_DSSChar[1];
				int flag1 = Banderas_DSSChar[0];

				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE DSS MP-TCP";
				if (flag2 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx1:	SI HAY ACK";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx0:	NO HAY ACK";
				}
				if (flag1 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx1x:	ACK(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x0xx:	NO HAY DSN/SSN/DLL/CHECKSUM";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx0x:	NO HAY ACK(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x0xx:	NO HAY DSN/SSN/DLL/CHECKSUM";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				}

				// EN FUNCIÓN DEL LOS 2 BITS PRESENTES EN ESTE BYTE SE PUEDE
				// EXTRAER INFORMACIÓN DEL
				// ACK(8 BYTES), CON AYUDA DE LOS MÉTODOS DE LA CLASE
				// "PacketParsingUtils", QUE REALIZA
				// A CONTINUACIÓN:

				if (flag1 == UNOChar[0]) {
					// VALOR DE ACK (8 BYTES)
					byte[] ACK8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
							Puntero + 4);
					String ACK8String = PacketParsingUtils.extraer8B_reduccion(ACK8Raw);
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(8 BYTES):			" + ACK8String;
				}
			}
			// SI LA LONGUTUD DE LOS BITS DE LA BANDERA ES 1 BIT SE PROCEDE A
			// REALIZAR EL ANÁLISIS
			// PRESENTADO A CONTINUACIÓN:

			if (Longitud_BanderaDSSEntero == 1) {
				int UNOEntero = 1;
				String UNOString = Integer.toBinaryString(UNOEntero);
				char UNOChar[] = UNOString.toCharArray();
				int flag1 = Banderas_DSSChar[0];

				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "---BANDERAS DEL MENSAJE DSS MP-TCP";
				if (flag1 == UNOChar[0]) {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx1:	SI HAY ACK";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx0x:	NO HAY ACK(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x0xx:	NO HAY DSN/SSN/DLL/CHECKSUM";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";

					// EN FUNCIÓN DEL BIT PRESENTE EN ESTE BYTE DE BANDERAS SE
					// PUEDE EXTRAER INFORMACIÓN COMO
					// EL ACK DE 4 BYTES, CON AYUDA DE LOS MÉTODOS DE LA CLASE
					// "PacketParsingUtils",
					// QUE REALIZA A CONTINUACIÓN:
					byte[] ACK4Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
							Puntero + 4);
					String ACK4String = PacketParsingUtils.extraer4B_reduccion(ACK4Raw);
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ACK(4 BYTES):			" + ACK4String;
				} else {
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xxx1:	NO HAY ACK";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x xx0x:	NO HAY ACK(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x x0xx:	NO HAY DSN/SSN/DLL/CHECKSUM";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---x 0xxx:	NO HAY DSN(8 BYTES)";
					DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "	---0 xxxx:	NO HAY DATA FIN";
				}
			}
		}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// ADD
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ADDRESS////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// PARA DETERMINAR SI ESTE ES UN MENSAJE DEL SUBTIPO ADD ADDRESS MP-TCP
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// REALIZARÁ
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// UNA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// COMPARACIÓN
		// ENTRE LA VARIABLE "SubtipoMPTCPEntero" Y EL ENTERO "3", SI SE CUMPLE,
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// AÑADIRÁ
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// INFORMACIÓN
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// DE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ESTE
		// SUBTIPO DE MENSAJE A LA VARIABLE DE TIPO STRING "DatosSubtipoMP_TCP.

		if (SubtipoMPTCPEntero == 3) {
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ADD ADDRESS MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;
			// SE EXTRAEN DOS BYTES DEL ARREGLO DE BYTES, CON EL PRIMER BYTE SE
			// DETERMINARÁ LA LONGITUD
			// DEL MENSAJE DEL SUBTIPO ADD ADDRESS MP-TCP, Y CON EL SEGUNDO BYTE
			// LA VERSIÓN DE IP Y SE
			// AÑADIRÁ ESTA INFORMACIÓN A LA VARIABLE DE TIPO STRING
			// "DatosSubtipoMP_TCP.
			byte Longitud_Add_Address_Byte = OpcionesTCPRaw[Puntero + 1];
			byte Version_IP_MPTCP_Byte = OpcionesTCPRaw[Puntero + 2];
			int Version_IP_MPTCP_Entero = (Version_IP_MPTCP_Byte & 0xf);
			String Version_IP_MPTCP_String = Integer.toHexString(Version_IP_MPTCP_Entero);
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VERSIÓN DE IP ES:		" + Version_IP_MPTCP_String;

			// SE EXTRAE EL BYTE QUE CORRESPONDE AL INDENTIFICADOR DE DIRECCION
			// DEL ARREGLO DE BYTES
			// "OpcionesTCPRaw",Y SE AÑADIRÁ ESTA INFORMACIÓN A LA VARIABLE DE
			// TIPO STRING
			// "DatosSubtipoMP_TCP.
			byte Identificador_direccion_Byte = OpcionesTCPRaw[Puntero + 3];
			int Identificador_direccion_Entero = (Identificador_direccion_Byte & 0xff);
			String Identificador_direccion_String = Integer.toString(Identificador_direccion_Entero);
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "IDENTIFICADOR DE DIRECCION:	"
					+ Identificador_direccion_String;
			// EL ANÁLISIS DEL MENSAJE DEL SUBTIPO ADD ADDRESS SE REALIZA EN
			// FUNCIÓN DEL LA LONGITUD,
			// PARA DETERMINAR SI SE TRATA DE DIRECCIONES IPV4, IPV4+PUERTO,
			// IPV6, O IPV6+PUERTO.
			if (Longitud_Add_Address_Byte == 8) {
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ES IPv4 Y NO TIENE NÚMERO DE PUERTO";
				// DIRECCIÓN IPV4
				byte[] Address_IPV4_Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4);
				String Address_IPV4_String = PacketParsingUtils.rawIpToString(Address_IPV4_Raw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "IPv4 ADD ADDRESS:		" + Address_IPV4_String;
			}
			if (Longitud_Add_Address_Byte == 10) {
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ES IPv4 Y TIENE NÚMERO DE PUERTO";
				// DIRECCIÓN IPV4 + NÚMERO DE PUERTO
				byte[] Address_IPV4_Raw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable,
						Puntero + 4);
				String Address_IPV4_String = PacketParsingUtils.rawIpToString(Address_IPV4_Raw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "IPv4 ADD ADDRESS:		" + Address_IPV4_String;

				byte[] PUERTORaw = PacketParsingUtils.extraer4B(PayloadTramaCapturada, CabeceraIPVariable, Puntero + 8);
				String PUERTOString = PacketParsingUtils.extraer4B_reduccion(PUERTORaw);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "NÚMERO DE PUERTO:		" + PUERTOString;
			}
			if (Longitud_Add_Address_Byte == 20) {
				// DIRECCIÓN IPV6
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ES IPv6 Y NO TIENE NÚMERO DE PUERTO";
			}
			if (Longitud_Add_Address_Byte == 22) {
				// DIRECCIÓN IPV6 + NÚMERO DE PUERTO
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "ES IPv6 Y TIENE NÚMERO DE PUERTO";
			}
		}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// REMOVE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ADDRESS/////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// PARA DETERMINAR SI ESTE ES UN MENSAJE DEL SUBTIPO REMOVE ADDRESS
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// MP-TCP
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// REALIZARÁ
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// UNA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// COMPARACIÓN
		// ENTRE LA VARIABLE "SubtipoMPTCPEntero" Y EL ENTERO "4", SI SE CUMPLE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ESTA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// CONDICIÓN,
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Y
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// AÑADIRÁ
		// INFORMACIÓN DE ESTE SUBTIPO DE MENSAJE A LA VARIABLE DE TIPO STRING
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// "DatosSubtipoMP_TCP

		if (SubtipoMPTCPEntero == 4) {
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "REMOVE ADDRESS MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;

			byte Longitud_REMOVE_ADDRESS_Byte = OpcionesTCPRaw[Puntero + 1];
			// UNA VEZ QUE SE EXTRAE AL INFORMACIÓN DE LA LONGITUD DEL MENSAJE
			// DEL SUBTIPO REMOVE ADDRESS,
			// SE RE REALIZA UN ANÁLISIS EN FUNCIÓN DE DICHA LONGITUD, YA QUE EN
			// FUNCIÓN DE ESTE VALOR
			// SE DETERMINA EL NÚMERO DE IDENTIFICADORES DE DIRECCION PRESENTES
			// EN ESTE MENSAJE.
			if (Longitud_REMOVE_ADDRESS_Byte == 4) {
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HAY (1) IDENTIFICADOR DE DIRECCION";
				byte ADDRESS_ID_MPTCP_Byte = OpcionesTCPRaw[Puntero + 3];
				int ADDRESS_ID_MPTCP_Entero = (ADDRESS_ID_MPTCP_Byte & 0xff);
				String ADDRESS_ID_MPTCP_String = Integer.toString(ADDRESS_ID_MPTCP_Entero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (1) ES:"
						+ ADDRESS_ID_MPTCP_String;
			}
			if (Longitud_REMOVE_ADDRESS_Byte == 5) {
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HAY (2) IDENTIFICADORES DE DIRECCION";
				byte ADDRESS_ID_MPTCP_Byte = OpcionesTCPRaw[Puntero + 3];
				int ADDRESS_ID_MPTCP_Entero = (ADDRESS_ID_MPTCP_Byte & 0xff);
				String ADDRESS_ID_MPTCP_String = Integer.toString(ADDRESS_ID_MPTCP_Entero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (1) ES: "
						+ ADDRESS_ID_MPTCP_String;
				byte ADDRESS_ID_MPTCP_Byte2 = OpcionesTCPRaw[Puntero + 4];
				int ADDRESS_ID_MPTCP_Entero2 = (ADDRESS_ID_MPTCP_Byte2 & 0xff);
				String ADDRESS_ID_MPTCP_String2 = Integer.toString(ADDRESS_ID_MPTCP_Entero2);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (2) ES: "
						+ ADDRESS_ID_MPTCP_String2;
			}

			if (Longitud_REMOVE_ADDRESS_Byte == 6) {
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HAY (3) IDENTIFICADORES DE DIRECCION";
				byte ADDRESS_ID_MPTCP_Byte = OpcionesTCPRaw[Puntero + 3];
				int ADDRESS_ID_MPTCP_Entero = (ADDRESS_ID_MPTCP_Byte & 0xff);
				String ADDRESS_ID_MPTCP_String = Integer.toString(ADDRESS_ID_MPTCP_Entero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (1) ES: "
						+ ADDRESS_ID_MPTCP_String;
				byte ADDRESS_ID_MPTCP_Byte2 = OpcionesTCPRaw[Puntero + 4];
				int ADDRESS_ID_MPTCP_Entero2 = (ADDRESS_ID_MPTCP_Byte2 & 0xff);
				String ADDRESS_ID_MPTCP_String2 = Integer.toString(ADDRESS_ID_MPTCP_Entero2);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (2) ES: "
						+ ADDRESS_ID_MPTCP_String2;
				byte ADDRESS_ID_MPTCP_Byte3 = OpcionesTCPRaw[Puntero + 5];
				int ADDRESS_ID_MPTCP_Entero3 = (ADDRESS_ID_MPTCP_Byte3 & 0xff);
				String ADDRESS_ID_MPTCP_String3 = Integer.toString(ADDRESS_ID_MPTCP_Entero3);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (3) ES: "
						+ ADDRESS_ID_MPTCP_String3;
			}
			if (Longitud_REMOVE_ADDRESS_Byte == 7) {
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "HAY (4) IDENTIFICADORES DE DIRECCION";
				byte ADDRESS_ID_MPTCP_Byte = OpcionesTCPRaw[Puntero + 3];
				int ADDRESS_ID_MPTCP_Entero = (ADDRESS_ID_MPTCP_Byte & 0xff);
				String ADDRESS_ID_MPTCP_String = Integer.toString(ADDRESS_ID_MPTCP_Entero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (1) ES: "
						+ ADDRESS_ID_MPTCP_String;
				byte ADDRESS_ID_MPTCP_Byte2 = OpcionesTCPRaw[Puntero + 4];
				int ADDRESS_ID_MPTCP_Entero2 = (ADDRESS_ID_MPTCP_Byte2 & 0xff);
				String ADDRESS_ID_MPTCP_String2 = Integer.toString(ADDRESS_ID_MPTCP_Entero2);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (2) ES: "
						+ ADDRESS_ID_MPTCP_String2;
				byte ADDRESS_ID_MPTCP_Byte3 = OpcionesTCPRaw[Puntero + 5];
				int ADDRESS_ID_MPTCP_Entero3 = (ADDRESS_ID_MPTCP_Byte3 & 0xff);
				String ADDRESS_ID_MPTCP_String3 = Integer.toString(ADDRESS_ID_MPTCP_Entero3);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (3) es: "
						+ ADDRESS_ID_MPTCP_String3;
				byte ADDRESS_ID_MPTCP_Byte4 = OpcionesTCPRaw[Puntero + 6];
				int ADDRESS_ID_MPTCP_Entero4 = (ADDRESS_ID_MPTCP_Byte4 & 0xff);
				String ADDRESS_ID_MPTCP_String4 = Integer.toString(ADDRESS_ID_MPTCP_Entero4);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION (4) es: "
						+ ADDRESS_ID_MPTCP_String4;
			}

		}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// MP_PRIORITY////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// PARA DETERMINAR SI ESTE ES UN MENSAJE DEL SUBTIPO MP_PRIORITY SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// REALIZARÁ
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// UNA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// COMPARACIÓN
		// ENTRE LA VARIABLE "SubtipoMPTCPEntero" Y EL ENTERO "5", SI SE CUMPLE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ESTA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// CONDICIÓN,
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// SE
		// AÑADIRÁ INFORMACIÓN DE ESTE SUBTIPO DE MENSAJE A LA VARIABLE DE TIPO
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// STRING
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// "DatosSubtipoMP_TCP.

		if (SubtipoMPTCPEntero == 5) {
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "PRIORIDAD MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;

			byte Longitud_MP_PRIO_Byte = OpcionesTCPRaw[Puntero + 1];
			int Longitud_MP_PRIO_Entero = (Longitud_MP_PRIO_Byte & 0xff);
			// UNA VEZ QUE SE EXTRAE AL INFORMACIÓN DE LA LONGITUD DEL MENSAJE
			// DEL SUBTIPO MP-PRIORITY,
			// SE RE REALIZA UN ANÁLISIS EN FUNCION DE DICHA LONGITUD, YA QUE EN
			// FUNCIÓN DE ESTE VALOR
			// SE DETERMINA LA PRESENCIA DE ADDRESS ID Y DEL BIT BACKUP.

			if (Longitud_MP_PRIO_Entero == 4) {
				byte Backup_MPTCP_Byte = OpcionesTCPRaw[Puntero + 2];
				int Backup_MPTCP_Entero = (Backup_MPTCP_Byte & 0xf);
				String Backup_MPTCP_String = Integer.toString(Backup_MPTCP_Entero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "BIT DE BACKUP MP_TCP:	" + Backup_MPTCP_String;
				int ADDRESS_ID_MPTCP_Entero = (OpcionesTCPRaw[3] & 0xf);
				String ADDRESS_ID_MPTCP_String = Integer.toString(ADDRESS_ID_MPTCP_Entero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "VALOR DEL IDENTIFICADOR DE DIRECCION ES:"
						+ ADDRESS_ID_MPTCP_String;
			} else {
				byte Backup_MPTCP_Byte = OpcionesTCPRaw[Puntero + 2];
				int Backup_MPTCP_Entero = (Backup_MPTCP_Byte & 0xf);
				String Backup_MPTCP_String = Integer.toString(Backup_MPTCP_Entero);
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "BIT DE BACKUP MP_TCP:	" + Backup_MPTCP_String;
				DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "NO HAY VALOR DE IDENTIFICADOR DE DIRECCION ";
			}
		}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// FALLBACK///////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// PARA DETERMINAR SI ESTE ES UN MENSAJE DEL SUBTIPO FALLBACK SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// REALIZARÁ
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// UNA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// COMPARACIÓN
		// ENTRE LA VARIABLE "SubtipoMPTCPEntero" Y EL ENTERO "5", SI SE CUMPLE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ESTA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// CONDICIÓN,
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// AÑADIRÁ
		// INFORMACIÓN DE ESTE SUBTIPO DE MENSAJE A LA VARIABLE DE TIPO STRING
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// "DatosSubtipoMP_TCP

		if (SubtipoMPTCPEntero == 6) {
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "FALLBACK MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;
			// SE EXTRAE EL ARREGLO DE BTYES DEL DATA SEQUENCE NUMBER Y CON UN
			// MÉTODO DE LA CLASE
			// "PacketParsingUtils" SE TRANSFORMA A TIPO STRING, Y SE AÑADE
			// DICHO STRING A LA VARIABLE
			// TIPO STRING "DatosSubtipoMP_TCP".
			byte[] DSN8Raw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable, Puntero + 4);
			String DSN8String = PacketParsingUtils.extraer8B_reduccion(DSN8Raw);
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "DATA SEQUENCE NUMBER(8 BYTES):		" + DSN8String;
		}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////// MP_FASTCLOSE///////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// PARA DETERMINAR SI ESTE ES UN MENSAJE DEL SUBTIPO MP_FASTCLOSE SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// REALIZARÁ
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// UNA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// COMPARACIÓN
		// ENTRE LA VARIABLE "SubtipoMPTCPEntero" Y EL ENTERO "7", SI SE CUMPLE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// LA
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// CONDICIÓN,
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// SE
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// AÑADIRÁ
		// INFORMACIÓN DE ESTE SUBTIPO DE MENSAJE A LA VARIABLE DE TIPO STRING
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// "DatosSubtipoMP_TCP
		if (SubtipoMPTCPEntero == 7) {
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "FASTCLOSE MP-TCP";
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "SUBTIPO MP-TCP:		" + SubtipoMPTCPString;
			// SE EXTRAE EL ARREGLO DE BTYES DE LA LLAVE DEL RECEPTOR CON UN
			// MÉTODO DEL LA CLASE
			// "PacketParsingUtils", SE TRANSFORMA A TIPO STRING Y SE AÑADE
			// DICHO STRING A LA VARIABLE
			// TIPO STRING "DatosSubtipoMP_TCP".

			byte[] ReceiverKeyRaw = PacketParsingUtils.extraer8B(PayloadTramaCapturada, CabeceraIPVariable,
					Puntero + 4);
			String ReceiverKeyString = PacketParsingUtils.extraer8B_reduccion(ReceiverKeyRaw);
			DatosSubtipoMP_TCP = DatosSubtipoMP_TCP + "," + "LLAVE DEL RECEPTOR (FASTCLOSE):	" + ReceiverKeyString;
		}

	}
}