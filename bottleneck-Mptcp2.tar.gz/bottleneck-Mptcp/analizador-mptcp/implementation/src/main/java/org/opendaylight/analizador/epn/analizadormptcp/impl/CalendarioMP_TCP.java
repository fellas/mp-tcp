package org.opendaylight.analizador.epn.analizadormptcp.impl;
//SE IMPORTA LA CLASE CALENDAR, PARA OBTENER FECHA Y HORA ACTUAL DEL SISTEMA.
import java.util.Calendar;
public class CalendarioMP_TCP {
	private Calendar calendario;
	//DEFINICIÓN DE LAS VARIABLES PARA DETERMINAR LA FECHA Y HORA 
	public String dia , mes, annio, hora, minutos, segundos;
	public CalendarioMP_TCP() {
		//INVOCACIÓN AL MÉTODO inicializar(), PARA DETERMINAR EL VALOR
		//LAS VARIABLES QUE INDICAN LA FECHA Y HORA
		inicializar();
	}
	//SE DETERMINAN LAS VARIABLES DE LA FECHA Y HORA PARA LA CREACIÓN DE ARCHIVOS 
	//XLS QUE CONTIENEN LOS MENSAJES DECODIFICADOS POR EL ANALIZADOR
	public void inicializar() {
		calendario = Calendar.getInstance();
		//DETERMINACIÓN DEL DÍA ACTUAL DEL SISTEMA
		dia = Integer.toString(calendario.get(Calendar.DATE));
		if(dia.length()==1){
			String cero = "0";
			dia=cero+dia;}
		//DETERMINACION DEL MES ACTUAL DEL SISTEMA
		int mes_entero=calendario.get(Calendar.MONTH);
		//SE DETERMINA EL NOMBRE DEL MES, EN FUNCIÓN DEL NUMERO
		//DE MES OBTENIDO PREVIAMENTE
		switch(mes_entero){
		case 0:
		{mes="Enero";
			break;}
		case 1:
		{mes="Febrero";
			break;}
		case 2:
		{mes="Marzo";
			break;}
		case 3:
		{mes="Abril";
			break;}
		case 4:
		{mes="Mayo";
			break;}
		case 5:
		{mes="Junio";
			break;}
		case 6:
		{mes="Julio";
			break;}
		case 7:
		{mes="Agosto";
			break;}
		case 8:
		{mes="Septiembre";
			break;}
		case 9:
		{mes="Octubre";
			break;}
		case 10:
		{mes="Noviembre";
			break;}
		case 11:
		{mes="Diciembre";
			break;}
		default:
		{mes="Error";
			break;}
		}
		//DETERMINACION DEL AÑO ACTUAL DEL SISTEMA
		annio = Integer.toString(calendario.get(Calendar.YEAR));
		//DETERMINACION DE LA HORA ACTUAL DEL SISTEMA
		hora =Integer.toString(calendario.get(Calendar.HOUR_OF_DAY));
		if(hora.length()==1){
			String cero = "0";
			hora=cero+hora;
		}
		//DETERMINACION DEL MINUTO ACTUAL DEL SISTEMA
		minutos = Integer.toString(calendario.get(Calendar.MINUTE));
		if(minutos.length()==1){
			String cero = "0";
			minutos=cero+minutos;
		}
		//DETERMINACION DEL SEGUNDO ACTUAL DEL SISTEMA
		segundos = Integer.toString(calendario.get(Calendar.SECOND));
		if(segundos.length()==1){
			String cero = "0";
			segundos=cero+segundos;
		}

	}

}

